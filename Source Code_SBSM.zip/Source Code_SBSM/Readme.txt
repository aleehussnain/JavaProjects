Following are some steps which need to be followed


1. Extract Folder and import it into netbeans
2. Run Xammp Server.
3. Right click on  project and click on run.
4. Enter username(admin) and password(admin).