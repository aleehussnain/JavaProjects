/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class SqlConnection {
    
     public static Connection getConnection() {
        System.out.println("Connection started");
        Connection con = null;

        String databaseName = "garments";
        String user = "root";
        String password = "root";


        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + databaseName,user,password);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            System.err.println("error in connection");
            e.printStackTrace();
        }
        System.out.println("Conneceted");
        return con;
    }
    
    public static void main(String[] args) {
        new SqlConnection().getConnection();
    }
    
}
