/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package garment;

import connection.SqlConnection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;


public class SupplierView extends javax.swing.JFrame {

    Connection connection = null;
    PreparedStatement prepearedStatement = null;
    ResultSet resultSet = null;

   
    public SupplierView() {
        initComponents();
        this.setLocationRelativeTo(null);
        action();
        connection = SqlConnection.getConnection();
        loadItemTypesToTable();
        try {
            setIconImage(ImageIO.read(new File("gem_shop_icon.png")));
        } catch (IOException ex) {
            Logger.getLogger(JohnGarments.class.getName()).log(Level.SEVERE, null, ex);
        }
        setTitle("AMANAT GARMENTS");
    }
private void action(){
     txt_sname.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt_sphone.requestFocusInWindow();
            }
        });
       
        txt_sphone.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt_saddress.requestFocusInWindow();
            }
        });
        txt_saddress.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt_sname.requestFocusInWindow();
            }
        });
}
    private ResultSet runS(String q) {
        try {
            prepearedStatement = connection.prepareStatement(q);
            resultSet = prepearedStatement.executeQuery();
            if (!resultSet.equals(null)) {
                return resultSet;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }

    private boolean runI(String q) {
        try {
            prepearedStatement = connection.prepareStatement(q);
            prepearedStatement.execute();
            return true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }

    public void loadItemTypesToTable() {

        try {
            resultSet = runS("Select * from suppliers ");
            if (!resultSet.equals(null)) {
                itemtypessTbl.setModel(DbUtils.resultSetToTableModel(resultSet));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //load table data to fields by select
    public void tableDataToFields() {
        int r = itemtypessTbl.getSelectedRow();
        String itemtypeid = itemtypessTbl.getValueAt(r, 0).toString();
        String itemtypename = itemtypessTbl.getValueAt(r, 1).toString();
        String itemtyphone = itemtypessTbl.getValueAt(r, 2).toString();
        String itemtypaddress = itemtypessTbl.getValueAt(r, 3).toString();

        // itemtypeIdLbl.setText(itemtypeid);
        txt_sname.setText(itemtypename);
        txt_saddress.setText(itemtypaddress);
        txt_sphone.setText(itemtyphone);
        lbl_sid.setText(itemtypeid);
        lblname.setText(itemtypename);

    }

    public void Clear() {

        txt_sname.setText("");
        txt_saddress.setText("");
        txt_sphone.setText("");
        lbl_sid.setText("");
    }
     public void Clear1() {

        txt_sup_rent_pay.setText("");
        txt_sup_rent_total.setText("");
        txt_remain.setText("");
       // lbl_sid.setText("");
    }

    public void updateItemTypes() {
        if (!txt_sname.getText().equals("") && !txt_sphone.getText().equals("")) {
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());

            String itemtypeid = lbl_sid.getText();

            try {

                if (runI("UPDATE `suppliers` SET `name`='" + txt_sname.getText() + "',`phone`='" + txt_sphone.getText() + "',`address`='" + txt_saddress.getText() + "' WHERE id='" + itemtypeid + "'")) {
                    if(runI("update leftovers set name='"+txt_sname.getText()+"' where name='"+lblname.getText()+"'"))
                        if(runI("update items set supplier = '"+txt_sname.getText()+"' where supplier ='"+lblname.getText()+"'"))
                    JOptionPane.showMessageDialog(null, "Supplier Updated !");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Fields can not be empty !");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        parentPanel = new javax.swing.JPanel();
        dataPanel = new javax.swing.JPanel();
        iteminputpanel = new javax.swing.JPanel();
        txt_sname = new javax.swing.JTextField();
        searchLbl2 = new javax.swing.JLabel();
        searchLbl3 = new javax.swing.JLabel();
        txt_sphone = new javax.swing.JTextField();
        searchLbl4 = new javax.swing.JLabel();
        searchLbl5 = new javax.swing.JLabel();
        txt_saddress = new javax.swing.JTextField();
        btnpanel = new javax.swing.JPanel();
        createBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        clearBtn = new javax.swing.JButton();
        lbl_sid = new javax.swing.JLabel();
        createBtn1 = new javax.swing.JButton();
        txt_sup_rent_total = new javax.swing.JTextField();
        txt_sup_rent_pay = new javax.swing.JTextField();
        searchLbl6 = new javax.swing.JLabel();
        searchLbl7 = new javax.swing.JLabel();
        searchLbl8 = new javax.swing.JLabel();
        txt_remain = new javax.swing.JTextField();
        createBtn2 = new javax.swing.JButton();
        lblname = new javax.swing.JLabel();
        new_total = new javax.swing.JButton();
        viewPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemtypessTbl = new javax.swing.JTable();
        itmsLbl = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblsupLoad = new javax.swing.JTable();
        lblLogo = new javax.swing.JLabel();
        lblClose = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        parentPanel.setBackground(new java.awt.Color(102, 102, 102));
        parentPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 255), 10));

        dataPanel.setBackground(new java.awt.Color(0, 153, 153));
        dataPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        iteminputpanel.setBackground(new java.awt.Color(204, 204, 255));
        iteminputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        iteminputpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        iteminputpanel.add(txt_sname, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 316, 35));

        searchLbl2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl2.setText(" Suppier Name:");
        iteminputpanel.add(searchLbl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, 30));

        searchLbl3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl3.setText("Address:");
        iteminputpanel.add(searchLbl3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 130, 30));

        txt_sphone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_sphoneKeyTyped(evt);
            }
        });
        iteminputpanel.add(txt_sphone, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, 316, 35));

        searchLbl4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl4.setText("Ph number:");
        iteminputpanel.add(searchLbl4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 130, 30));

        searchLbl5.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl5.setText("Address:");
        iteminputpanel.add(searchLbl5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 130, 30));
        iteminputpanel.add(txt_saddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 320, 35));

        btnpanel.setBackground(new java.awt.Color(204, 204, 255));
        btnpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        createBtn.setBackground(new java.awt.Color(153, 255, 153));
        createBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn.setText("ADD");
        createBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(51, 51, 255));
        updateBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        updateBtn.setForeground(new java.awt.Color(255, 255, 255));
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(255, 102, 102));
        deleteBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        clearBtn.setBackground(new java.awt.Color(255, 255, 153));
        clearBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        clearBtn.setText("Clear");
        clearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout btnpanelLayout = new javax.swing.GroupLayout(btnpanel);
        btnpanel.setLayout(btnpanelLayout);
        btnpanelLayout.setHorizontalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        btnpanelLayout.setVerticalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, btnpanelLayout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39))
        );

        lbl_sid.setForeground(new java.awt.Color(204, 204, 255));
        lbl_sid.setText("jLabel1");

        createBtn1.setBackground(new java.awt.Color(255, 153, 102));
        createBtn1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn1.setText("Load");
        createBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtn1ActionPerformed(evt);
            }
        });

        txt_sup_rent_total.setEditable(false);

        txt_sup_rent_pay.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_sup_rent_payKeyTyped(evt);
            }
        });

        searchLbl6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl6.setText("Total:");

        searchLbl7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl7.setText("Paid:");

        searchLbl8.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl8.setText("Remaining:");

        txt_remain.setEditable(false);

        createBtn2.setBackground(new java.awt.Color(153, 255, 153));
        createBtn2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn2.setText("Pay");
        createBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtn2ActionPerformed(evt);
            }
        });

        lblname.setBackground(new java.awt.Color(204, 204, 255));
        lblname.setForeground(new java.awt.Color(204, 204, 255));
        lblname.setText("jLabel1");

        new_total.setBackground(new java.awt.Color(255, 153, 102));
        new_total.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        new_total.setText("New Total");
        new_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new_totalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout dataPanelLayout = new javax.swing.GroupLayout(dataPanel);
        dataPanel.setLayout(dataPanelLayout);
        dataPanelLayout.setHorizontalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dataPanelLayout.createSequentialGroup()
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(iteminputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 580, Short.MAX_VALUE)
                            .addComponent(btnpanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dataPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblname)
                        .addGap(146, 146, 146)
                        .addComponent(lbl_sid)
                        .addGap(224, 224, 224))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dataPanelLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(dataPanelLayout.createSequentialGroup()
                                .addComponent(createBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(createBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(new_total, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(searchLbl6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(searchLbl7, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(searchLbl8, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txt_sup_rent_total, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txt_sup_rent_pay, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txt_remain, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );
        dataPanelLayout.setVerticalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbl_sid)
                    .addComponent(lblname))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(iteminputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dataPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_sup_rent_total, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_sup_rent_pay, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dataPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(new_total, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)))
                .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dataPanelLayout.createSequentialGroup()
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchLbl8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_remain, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dataPanelLayout.createSequentialGroup()
                        .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(createBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(createBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );

        viewPanel.setBackground(new java.awt.Color(102, 102, 102));
        viewPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jScrollPane1.setBackground(new java.awt.Color(153, 153, 255));

        itemtypessTbl.setBackground(new java.awt.Color(204, 204, 204));
        itemtypessTbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        itemtypessTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "item type name"
            }
        ));
        itemtypessTbl.setGridColor(new java.awt.Color(204, 204, 204));
        itemtypessTbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        itemtypessTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemtypessTblMouseClicked(evt);
            }
        });
        itemtypessTbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                itemtypessTblKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                itemtypessTblKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(itemtypessTbl);

        itmsLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        itmsLbl.setText("Suppliers");

        jScrollPane2.setBackground(new java.awt.Color(153, 153, 255));

        tblsupLoad.setBackground(new java.awt.Color(204, 204, 204));
        tblsupLoad.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tblsupLoad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "item type name"
            }
        ));
        tblsupLoad.setGridColor(new java.awt.Color(204, 204, 204));
        tblsupLoad.setSelectionBackground(new java.awt.Color(153, 153, 255));
        tblsupLoad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblsupLoadMouseClicked(evt);
            }
        });
        tblsupLoad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tblsupLoadKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tblsupLoadKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(tblsupLoad);

        javax.swing.GroupLayout viewPanelLayout = new javax.swing.GroupLayout(viewPanel);
        viewPanel.setLayout(viewPanelLayout);
        viewPanelLayout.setHorizontalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(173, 173, 173))
            .addGroup(viewPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE))
                .addContainerGap())
        );
        viewPanelLayout.setVerticalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewPanelLayout.createSequentialGroup()
                .addComponent(itmsLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        lblLogo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        lblLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLogo.setText("Supplier Management");

        lblClose.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        lblClose.setForeground(new java.awt.Color(255, 255, 255));
        lblClose.setText("X");
        lblClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCloseMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout parentPanelLayout = new javax.swing.GroupLayout(parentPanel);
        parentPanel.setLayout(parentPanelLayout);
        parentPanelLayout.setHorizontalGroup(
            parentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(parentPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(parentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(parentPanelLayout.createSequentialGroup()
                        .addComponent(dataPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(viewPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, parentPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(342, 342, 342)
                        .addComponent(lblClose, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        parentPanelLayout.setVerticalGroup(
            parentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(parentPanelLayout.createSequentialGroup()
                .addGroup(parentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(parentPanelLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(lblLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblClose))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(parentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dataPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(viewPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(parentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(parentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCloseMouseClicked
        // close btn:
        this.dispose();
        JohnGarments m = new JohnGarments();
        m.setVisible(true);


    }//GEN-LAST:event_lblCloseMouseClicked

    private void createBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtnActionPerformed
        // create types:
        if (!txt_sname.getText().equals("") && !txt_sphone.getText().equals("")) {

            Timestamp timestamp = new Timestamp(System.currentTimeMillis());

            try {
                if (!search(txt_sname.getText())) {
                    if (runI("INSERT INTO `suppliers`(`name`, `phone`, `address`) VALUES('" + txt_sname.getText() + "'," + txt_sphone.getText() + ",'" + txt_saddress.getText() + "')")) {
                        if (runI("INSERT INTO `leftovers`(`name`, `total`, `paid`) VALUES ('" + txt_sname.getText() + "',0,0)")) {
                            JOptionPane.showMessageDialog(rootPane, "Supplier Succesfully Added !");
                        Clear1();
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Supplier name already exists!");

                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Fields can not be emptied!");
        }

        loadItemTypesToTable();
        Clear();

    }//GEN-LAST:event_createBtnActionPerformed

    private void clearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnActionPerformed
        // TODO add your handling code here:
       // tblsupLoad.setModel(DbUtils.resultSetToTableModel(null));
        Clear();
        setTableEmpty();
        Clear1();
        
    }//GEN-LAST:event_clearBtnActionPerformed
private void setTableEmpty(){
    DefaultTableModel model = (DefaultTableModel)this.tblsupLoad.getModel();
model.setRowCount(0);  
}
    private void itemtypessTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemtypessTblMouseClicked
        // TODO add your handling code here:
        tblsupLoad.setModel(DbUtils.resultSetToTableModel(resultSet));
     setTableEmpty();
tableDataToFields();
        Clear1();
    }//GEN-LAST:event_itemtypessTblMouseClicked

    private void itemtypessTblKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtypessTblKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemtypessTblKeyPressed

    private void itemtypessTblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtypessTblKeyReleased
        // TODO add your handling code here:
        tableDataToFields();
    }//GEN-LAST:event_itemtypessTblKeyReleased

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:
        updateItemTypes();
        loadItemTypesToTable();
        Clear();
        Clear1();
    }//GEN-LAST:event_updateBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // TODO add your handling code here:
        int check = JOptionPane.showConfirmDialog(null, "Do you want to Delete ? ");

        if (check == 0) {

            String itemid = lbl_sid.getText();

            try {
                if (runI("DELETE FROM suppliers WHERE id='" + itemid + "'")) {
                    if(runI("delete from leftovers where name='"+txt_sname.getText()+"'"))
                    JOptionPane.showMessageDialog(null, "Supplier Deleted !");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }

        }
        loadItemTypesToTable();
        Clear();
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void txt_sphoneKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_sphoneKeyTyped
        // TODO add your handling code here:
        checkInteger(txt_sphone, evt);
    }//GEN-LAST:event_txt_sphoneKeyTyped

    private void checkInteger(JTextField txt, java.awt.event.KeyEvent evt){
         String value = txt_sphone.getText();
        int l = value.length();
        if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyChar() == evt.VK_BACK_SPACE || evt.getKeyChar()== evt.VK_ENTER) {
            txt_sphone.setEditable(true);
        } else {
            txt_sphone.setEditable(false);
            JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
        }
    }
    private void createBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtn1ActionPerformed
        // TODO add your handling code here:
        if (!txt_sname.getText().equals("")) {

            resultSet = runS("call price('" + txt_sname.getText() + "')");
            
            if (resultSet != null) {
                tblsupLoad.setModel(DbUtils.resultSetToTableModel(resultSet));
                
                setLabels(txt_sname.getText());
                
            }

        } else {
            JOptionPane.showMessageDialog(null, "* Please select a supplier");

        }
    }//GEN-LAST:event_createBtn1ActionPerformed
private void setLabels(String name){
    try{
        if(runI("call update_leftover('"+name+"')")){
    resultSet = runS("select total,paid from leftovers where name = '"+name+"'");
    
    if(resultSet.next()){
       resultSet.first();
    String a = resultSet.getString("total");
    String b = resultSet.getString("paid");
            
    txt_sup_rent_total.setText(a+"");
    txt_sup_rent_pay.setText(b+"");
    txt_remain.setText((Integer.parseInt(a)- Integer.parseInt(b))+"");
    }
        }
    }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        
    }
}
    private void tblsupLoadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblsupLoadMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblsupLoadMouseClicked

    private void tblsupLoadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblsupLoadKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_tblsupLoadKeyPressed

    private void tblsupLoadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblsupLoadKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tblsupLoadKeyReleased

    private void createBtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtn2ActionPerformed
        // TODO add your handling code here:
        if(!txt_sname.getText().equals("") && !txt_sup_rent_pay.getText().equals("")){
        String val =txt_sup_rent_pay.getText();
        if(!val.equals("")){
            int a = Integer.parseInt(val);
            if(runI("update leftovers set paid = paid+"+a+" where name='"+lblname.getText()+"'"))
                            JOptionPane.showMessageDialog(null, "Successfully paid!");
            createBtn1ActionPerformed(evt);

        }
        }
    }//GEN-LAST:event_createBtn2ActionPerformed

    private void txt_sup_rent_payKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_sup_rent_payKeyTyped
        checkInteger(txt_remain, evt);
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txt_sup_rent_payKeyTyped

    private void new_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_new_totalActionPerformed
        // TODO add your handling code here:
         if (!txt_sname.getText().equals("")) {

            resultSet = runS("call current_total('" + txt_sname.getText() + "')");
            
            if (resultSet != null) {
                tblsupLoad.setModel(DbUtils.resultSetToTableModel(resultSet));
                
                setLabels1(txt_sname.getText());
                
            }

        } else {
            JOptionPane.showMessageDialog(null, "* Please select a supplier");

        }
    }//GEN-LAST:event_new_totalActionPerformed
   private void setLabels1(String name){
        try{
       
    resultSet = runS("call get_cur_total('"+name+"')");
    
    if(resultSet.next()){
       resultSet.first();
    String a = resultSet.getString("total");
            
    txt_sup_rent_total.setText(a+"");
    txt_sup_rent_pay.setText("0");
    txt_remain.setText(a+"");
    }
        
    }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        
    }
   }
   
   private boolean search(String name) {
        try {
            prepearedStatement = connection.prepareStatement("call Search_supplier('" + name + "')");

            resultSet = prepearedStatement.executeQuery();
            if (resultSet.next()) {
                if (resultSet.getString("one").equals("1")) {
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SupplierView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SupplierView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SupplierView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SupplierView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SupplierView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel btnpanel;
    private javax.swing.JButton clearBtn;
    private javax.swing.JButton createBtn;
    private javax.swing.JButton createBtn1;
    private javax.swing.JButton createBtn2;
    private javax.swing.JPanel dataPanel;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JPanel iteminputpanel;
    private javax.swing.JTable itemtypessTbl;
    private javax.swing.JLabel itmsLbl;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblClose;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lbl_sid;
    private javax.swing.JLabel lblname;
    private javax.swing.JButton new_total;
    private javax.swing.JPanel parentPanel;
    private javax.swing.JLabel searchLbl2;
    private javax.swing.JLabel searchLbl3;
    private javax.swing.JLabel searchLbl4;
    private javax.swing.JLabel searchLbl5;
    private javax.swing.JLabel searchLbl6;
    private javax.swing.JLabel searchLbl7;
    private javax.swing.JLabel searchLbl8;
    private javax.swing.JTable tblsupLoad;
    private javax.swing.JTextField txt_remain;
    private javax.swing.JTextField txt_saddress;
    private javax.swing.JTextField txt_sname;
    private javax.swing.JTextField txt_sphone;
    private javax.swing.JTextField txt_sup_rent_pay;
    private javax.swing.JTextField txt_sup_rent_total;
    private javax.swing.JButton updateBtn;
    private javax.swing.JPanel viewPanel;
    // End of variables declaration//GEN-END:variables
}
