/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package garment;

import connection.SqlConnection;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import net.proteanit.sql.DbUtils;


public class Items extends javax.swing.JFrame {

    Connection connection = null;
    PreparedStatement prepearedStatement = null;
    ResultSet resultSet = null;

    public Items() {
        initComponents();
        //  combo_suppliername.getEditor().setItem("deer");
        //setUndecorated(true);
        Action();
        this.setLocationRelativeTo(null);
        connection = SqlConnection.getConnection();
        loadItemToTable();
        fill_Combo();

        try {
            setIconImage(ImageIO.read(new File("gem_shop_icon.png")));
        } catch (IOException ex) {
            Logger.getLogger(JohnGarments.class.getName()).log(Level.SEVERE, null, ex);
        }
        setTitle("AMANAT GARMENTS");

    }

    private ResultSet runS(String q) {
        try {
            prepearedStatement = connection.prepareStatement(q);
            resultSet = prepearedStatement.executeQuery();
            if (!resultSet.equals(null)) {
                return resultSet;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }

    private boolean runI(String q) {
        try {
            prepearedStatement = connection.prepareStatement(q);
            prepearedStatement.execute();
            return true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }

    // saved item loading to the table
    public void loadItemToTable() {

        resultSet = runS("SELECT item_id AS ID,code ,item_name AS Name,supplier ,price AS Price, purchase as Purchase, "
                + "img as image, updated_date AS Updated,created_date AS added_Date from items order by supplier ");
        itemsTbl.setModel(DbUtils.resultSetToTableModel(resultSet));

    }

    public void fill_Combo() {
        combo_suppliername.removeAllItems();
        try {
            resultSet = runS("SELECT name from suppliers ");
            while (resultSet.next()) {
                combo_suppliername.addItem(resultSet.getString("name"));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }

    //load table data to fields by select
    public void tableDataToFields() {

        int r = itemsTbl.getSelectedRow();
        String itemid = itemsTbl.getValueAt(r, 0).toString();
        String code = itemsTbl.getValueAt(r, 1).toString();
        String itemname = itemsTbl.getValueAt(r, 2).toString();
        String supplier_name = itemsTbl.getValueAt(r, 3).toString();
        String itemprice = itemsTbl.getValueAt(r, 4).toString();
        String purchase = itemsTbl.getValueAt(r, 5).toString();
        String itemimg = itemsTbl.getValueAt(r, 6).toString();

        resultSet = runS("select qty from stocks where stock_id='" + itemid + "'");
        try {
            if (resultSet.next()) {
                resultSet.first();
                itemqty.setText(resultSet.getString("qty"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(Items.class.getName()).log(Level.SEVERE, null, ex);
        }

        combo_suppliername.setSelectedItem(supplier_name);
        itemidLbl.setText(itemid);
        itemnameTxt.setText(itemname);

        itempriceTxt.setText(itemprice);
        itempurchasetxt.setText(purchase);
        txt_code.setText(code);

        if (!itemimg.equals("null") && !itemimg.equals("")) {

            String path = "src\\images\\" + itemimg;
            imgaddresssTxt.setText(path);
            BufferedImage imgg = null;

            try {
                imgg = ImageIO.read(new File(path));
            } catch (IOException ex) {
                Logger.getLogger(Items.class.getName()).log(Level.SEVERE, null, ex);
            }
            Image image = imgg.getScaledInstance(imgLbl.getWidth(), imgLbl.getHeight(), Image.SCALE_DEFAULT);
            ImageIcon icon = new ImageIcon(image);
            imgLbl.setIcon(icon);
        } else {
            imgaddresssTxt.setText("");
        }
    }

    //update items
    public void updateItems() {
        if (!itemqty.getText().equals("") && !txt_code.getText().equals("") && !itemnameTxt.getText().equals("") && !itempriceTxt.getText().equals("") && !itempurchasetxt.getText().equals("") && combo_suppliername.getSelectedIndex() != -1) {
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            String itemid = itemidLbl.getText();
            String itemname = itemnameTxt.getText();
            String supplier = combo_suppliername.getSelectedItem().toString();
            String itemprice = itempriceTxt.getText();
            String pur = itempurchasetxt.getText();
            String code = txt_code.getText();
            String image;
            if (!imgaddresssTxt.equals("")) {
                image = imgaddresssTxt.getText();
                image = (String) image.subSequence(image.lastIndexOf("\\") + 1, image.length());
            } else {
                image = "";
            }

            //image.replace("\\", "\\\\");
            try {
                if (runI("UPDATE items SET code=" + code + " , item_name='" + itemname + "',supplier='" + supplier + "',price='"
                        + itemprice + "',purchase = '" + pur + "',img='" + image + "',updated_date='" + timestamp + "' WHERE item_id='" + itemid + "'")) {
                    if (runI("UPDATE stocks SET qty ='" + itemqty.getText() + "', total_qty='" + itemqty.getText() + "', item_code='" + code + "' WHERE stock_id='" + itemid + "'")) {
                        if (runI("call update_leftover ('" + supplier + "')")) {
                            JOptionPane.showMessageDialog(null, "Item Details Updated !");
                        }
                    }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Fields can not be empty !");
        }

    }

    public void clearfields() {
        itemqty.setText("");
        itemidLbl.setText("");
        itemnameTxt.setText("");
        //combo_suppliername.setSelectedIndex(0);
        itempriceTxt.setText("");
        searchTxt.setText("");
        // itemweight.setText("");
        searchTxt.setText("");
        imgaddresssTxt.setText("");
        itempurchasetxt.setText("");
        imgLbl.setIcon(null);
        txt_code.setText("");

    }

    public void search() {
        String srch = searchTxt.getText();

        try {
            resultSet = runS("SELECT * FROM items WHERE item_id LIKE'%" + srch + "%' OR item_name LIKE'" + srch + "'");
            itemsTbl.setModel(DbUtils.resultSetToTableModel(resultSet));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainpanel = new javax.swing.JPanel();
        dataPanel = new javax.swing.JPanel();
        findPanel = new javax.swing.JPanel();
        searchLbl = new javax.swing.JLabel();
        searchTxt = new javax.swing.JTextField();
        inputDataPanel = new javax.swing.JPanel();
        searchLbl1 = new javax.swing.JLabel();
        searchLbl4 = new javax.swing.JLabel();
        itemnameTxt = new javax.swing.JTextField();
        imgaddresssTxt = new javax.swing.JTextField();
        imgbrowseBtn = new javax.swing.JButton();
        itemidLbl = new javax.swing.JLabel();
        searchLbl6 = new javax.swing.JLabel();
        itempriceTxt = new javax.swing.JTextField();
        itempurchasetxt = new javax.swing.JTextField();
        searchLbl7 = new javax.swing.JLabel();
        imgLbl = new javax.swing.JLabel();
        txt_code = new javax.swing.JTextField();
        searchLbl8 = new javax.swing.JLabel();
        itemqty = new javax.swing.JTextField();
        searchLbl9 = new javax.swing.JLabel();
        combo_suppliername = new javax.swing.JComboBox<>();
        searchLbl2 = new javax.swing.JLabel();
        buttonPanel = new javax.swing.JPanel();
        createBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        clearBtn = new javax.swing.JButton();
        clearBtn1 = new javax.swing.JButton();
        viewPanel = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        itemsTbl = new javax.swing.JTable();
        itmsLbl = new javax.swing.JLabel();
        mainLbl = new javax.swing.JLabel();
        closeBtn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        mainpanel.setBackground(new java.awt.Color(102, 102, 102));
        mainpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 255), 10));

        dataPanel.setBackground(new java.awt.Color(102, 102, 102));
        dataPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        findPanel.setBackground(new java.awt.Color(0, 153, 153));
        findPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl.setText("Search");

        searchTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        searchTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchTxtActionPerformed(evt);
            }
        });
        searchTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchTxtKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout findPanelLayout = new javax.swing.GroupLayout(findPanel);
        findPanel.setLayout(findPanelLayout);
        findPanelLayout.setHorizontalGroup(
            findPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(findPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        findPanelLayout.setVerticalGroup(
            findPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(findPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(findPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        inputDataPanel.setBackground(new java.awt.Color(0, 204, 204));
        inputDataPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl1.setText("Item Name");

        searchLbl4.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl4.setText("Image");

        imgbrowseBtn.setFont(new java.awt.Font("Dialog", 1, 10)); // NOI18N
        imgbrowseBtn.setText("Browse");
        imgbrowseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imgbrowseBtnActionPerformed(evt);
            }
        });

        itemidLbl.setBackground(new java.awt.Color(204, 204, 255));
        itemidLbl.setForeground(new java.awt.Color(204, 204, 255));

        searchLbl6.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl6.setText("Purchase");

        itempriceTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itempriceTxtActionPerformed(evt);
            }
        });
        itempriceTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itempriceTxtKeyTyped(evt);
            }
        });

        itempurchasetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itempurchasetxtKeyTyped(evt);
            }
        });

        searchLbl7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl7.setText("Sale Price");

        txt_code.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_codeKeyTyped(evt);
            }
        });

        searchLbl8.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl8.setText("Item Code");

        itemqty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemqtyKeyTyped(evt);
            }
        });

        searchLbl9.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl9.setText("Qty:");

        searchLbl2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl2.setText("Supplier");

        javax.swing.GroupLayout inputDataPanelLayout = new javax.swing.GroupLayout(inputDataPanel);
        inputDataPanel.setLayout(inputDataPanelLayout);
        inputDataPanelLayout.setHorizontalGroup(
            inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputDataPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(inputDataPanelLayout.createSequentialGroup()
                        .addComponent(searchLbl4, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(imgaddresssTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(imgbrowseBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(inputDataPanelLayout.createSequentialGroup()
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inputDataPanelLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(searchLbl1))
                            .addGroup(inputDataPanelLayout.createSequentialGroup()
                                .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(itemidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(searchLbl6, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(searchLbl7, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(searchLbl8)
                                    .addComponent(searchLbl9, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(searchLbl2))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(combo_suppliername, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(itemqty, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                            .addComponent(itempriceTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(itemnameTxt)
                            .addComponent(txt_code, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(itempurchasetxt, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(imgLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        inputDataPanelLayout.setVerticalGroup(
            inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputDataPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inputDataPanelLayout.createSequentialGroup()
                        .addComponent(imgLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 355, Short.MAX_VALUE))
                    .addGroup(inputDataPanelLayout.createSequentialGroup()
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(combo_suppliername, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl2))
                        .addGap(4, 4, 4)
                        .addComponent(itemidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(itemnameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_code, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(itempriceTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl7, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(itempurchasetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 346, Short.MAX_VALUE)
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(itemqty, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchLbl9, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(imgbrowseBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(inputDataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(imgaddresssTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(searchLbl4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );

        buttonPanel.setBackground(new java.awt.Color(0, 204, 255));
        buttonPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        createBtn.setBackground(new java.awt.Color(153, 255, 153));
        createBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn.setText("Add");
        createBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(255, 255, 0));
        updateBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(255, 102, 102));
        deleteBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        clearBtn.setBackground(new java.awt.Color(255, 255, 153));
        clearBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        clearBtn.setText("Clear");
        clearBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearBtnMouseClicked(evt);
            }
        });
        clearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnActionPerformed(evt);
            }
        });

        clearBtn1.setBackground(new java.awt.Color(102, 102, 255));
        clearBtn1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        clearBtn1.setForeground(new java.awt.Color(255, 255, 255));
        clearBtn1.setText("Check Bill");
        clearBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearBtn1MouseClicked(evt);
            }
        });
        clearBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout buttonPanelLayout = new javax.swing.GroupLayout(buttonPanel);
        buttonPanel.setLayout(buttonPanelLayout);
        buttonPanelLayout.setHorizontalGroup(
            buttonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(updateBtn)
                .addGap(18, 18, 18)
                .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(clearBtn1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        buttonPanelLayout.setVerticalGroup(
            buttonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(buttonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout dataPanelLayout = new javax.swing.GroupLayout(dataPanel);
        dataPanel.setLayout(dataPanelLayout);
        dataPanelLayout.setHorizontalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(findPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(inputDataPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(buttonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        dataPanelLayout.setVerticalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(findPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inputDataPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        viewPanel.setBackground(new java.awt.Color(102, 102, 102));
        viewPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        scrollPane.setBackground(new java.awt.Color(153, 153, 255));

        itemsTbl.setBackground(new java.awt.Color(204, 204, 204));
        itemsTbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        itemsTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        itemsTbl.setGridColor(new java.awt.Color(204, 204, 204));
        itemsTbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        itemsTbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemsTblMouseClicked(evt);
            }
        });
        itemsTbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                itemsTblKeyReleased(evt);
            }
        });
        scrollPane.setViewportView(itemsTbl);

        itmsLbl.setBackground(new java.awt.Color(0, 153, 153));
        itmsLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        itmsLbl.setForeground(new java.awt.Color(255, 255, 255));
        itmsLbl.setText("ITEMS");

        javax.swing.GroupLayout viewPanelLayout = new javax.swing.GroupLayout(viewPanel);
        viewPanel.setLayout(viewPanelLayout);
        viewPanelLayout.setHorizontalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 669, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(286, 286, 286))
        );
        viewPanelLayout.setVerticalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewPanelLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 785, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );

        mainLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        mainLbl.setForeground(new java.awt.Color(255, 255, 255));
        mainLbl.setText("Items Management");

        closeBtn.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 255, 255));
        closeBtn.setText("X");
        closeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout mainpanelLayout = new javax.swing.GroupLayout(mainpanel);
        mainpanel.setLayout(mainpanelLayout);
        mainpanelLayout.setHorizontalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dataPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(viewPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainpanelLayout.createSequentialGroup()
                .addGap(511, 511, 511)
                .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(closeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        mainpanelLayout.setVerticalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(closeBtn)
                    .addComponent(mainLbl))
                .addGap(21, 21, 21)
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(viewPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dataPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(mainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeBtnMouseClicked
        // close btn:
        this.dispose();
        JohnGarments m = new JohnGarments();
        m.setVisible(true);

    }//GEN-LAST:event_closeBtnMouseClicked

    private void searchTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchTxtActionPerformed

    private void createBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtnActionPerformed
        // item adding:
        if (!txt_code.getText().equals("") && !itemnameTxt.getText().equals("") && !itempriceTxt.getText().equals("") && !itempurchasetxt.getText().equals("") && combo_suppliername.getSelectedIndex() != -1) {
            if (Integer.parseInt(itempurchasetxt.getText()) < Integer.parseInt(itempriceTxt.getText())) {
                if (!searchCode(txt_code.getText())) {
                    String[] sr = null;
                    String itemname, image = null, supplier_name, itemcode;
                    int itemprice, itempurchase;

                    //Timestamp 1
                    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                    String path = "null";
                    itemname = itemnameTxt.getText();
                    supplier_name = (String) combo_suppliername.getSelectedItem();
                    itemprice = Integer.parseInt(itempriceTxt.getText());
                    itempurchase = Integer.parseInt(itempurchasetxt.getText());
                    itemcode = txt_code.getText();
                    int qty = Integer.parseInt(itemqty.getText());

                    if (!imgaddresssTxt.getText().equals("") && !imgaddresssTxt.getText().equals("null")) {
                        /*  image = imgaddresssTxt.getText();
                         image = (String) image.subSequence(image.lastIndexOf("\\") + 1, image.length());*/
                        String filename = imgaddresssTxt.getText();
                        sr = filename.replace("\\", "/").split("/");

                        if (!filename.isEmpty()) {
                            try {
                                File sFile = new File(filename);
                                File dFile = new File("src/images/" + sr[sr.length - 1]);
                                Files.copy(sFile.toPath(), dFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                                path = sr[sr.length - 1];
                                // System.out.println("Scuccefully Copied");
                            } catch (Exception e) {
                                System.out.println("Not Copied");
                            }

                        }
                    }

                    try {

                        if (runI("INSERT INTO items (code,item_name,supplier,price,purchase,img,created_date) VALUES"
                                + "('" + itemcode + "','" + itemname + "','" + supplier_name + "'," + itemprice + "," + itempurchase + ",'" + path + "','" + timestamp + "')")) {
                            if (runI("INSERT INTO stocks (item_code, qty,state,total_qty, created_date ) VALUES "
                                    + "('" + itemcode + "','" + qty + "','available','" + qty + "','" + timestamp + "')")) {

                                if (runI("call update_leftover ('" + supplier_name + "')")) {
                                    JOptionPane.showMessageDialog(rootPane, "Item Succesfully Added !");
                                }

                            }
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                    }
                    loadItemToTable();
                    clearfields();

                } else {
                    JOptionPane.showMessageDialog(rootPane, "Item Code is already Available!");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Purchase price must be greater then Sale price!");
            }

        } else {
            JOptionPane.showMessageDialog(rootPane, "Fields can not be empty !");
        }


    }//GEN-LAST:event_createBtnActionPerformed
    private boolean searchCode(String name) {
        try {
            prepearedStatement = connection.prepareStatement("call search_code('" + name + "')");

            resultSet = prepearedStatement.executeQuery();
            if (resultSet.next()) {
                if (resultSet.getString("one").equals("1")) {
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }
    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:

        updateItems();
        loadItemToTable();
        clearfields();
    }//GEN-LAST:event_updateBtnActionPerformed

    private void itemsTblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemsTblMouseClicked
        // tableDataToFields():
        tableDataToFields();
    }//GEN-LAST:event_itemsTblMouseClicked

    private void itemsTblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemsTblKeyReleased
        // tableDataToFields():
        tableDataToFields();
    }//GEN-LAST:event_itemsTblKeyReleased

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // delete item:

        int check = JOptionPane.showConfirmDialog(null, "Do you want to Delete ? ");
        if (check == 0) {
            String itemid = itemidLbl.getText();
            try {
                if (runI("DELETE FROM stocks WHERE stock_id='" + itemid + "'")) {
                    if (runI("call update_call_to_leftover('" + itemid + "')")) {

                        if (runI("DELETE FROM items WHERE item_id='" + itemid + "'")) {
                            JOptionPane.showMessageDialog(null, "Item Deleted !");
                        }
                    }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }

            loadItemToTable();
            clearfields();

        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void searchTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchTxtKeyReleased
        // searchitems 
        search();
    }//GEN-LAST:event_searchTxtKeyReleased

    private void clearBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearBtnMouseClicked
        // TODO add your handling code here:

        clearfields();
    }//GEN-LAST:event_clearBtnMouseClicked

    private void clearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnActionPerformed
        // TODO add your handling code here:
        clearfields();
    }//GEN-LAST:event_clearBtnActionPerformed

    private void imgbrowseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imgbrowseBtnActionPerformed
        // TODO add your handling code here:
       // String desktopPath = WindowsUtils.getCurrentUserDesktopPath();
        
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File(System.getProperty("user.home")+"/Desktop"));
        chooser.setFileFilter(new FileNameExtensionFilter("Image","png","jpg","jpeg"));
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        if(f!=null){
        System.out.println(f);
        String filename = f.getAbsolutePath();
        imgaddresssTxt.setText(filename);
        BufferedImage imgg = null;
        try {
            imgg = ImageIO.read(new File(filename));
        } catch (IOException ex) {
            Logger.getLogger(Items.class.getName()).log(Level.SEVERE, null, ex);
        }
        Image image = imgg.getScaledInstance(imgLbl.getWidth(), imgLbl.getHeight(), Image.SCALE_DEFAULT);
        ImageIcon icon = new ImageIcon(image);
        imgLbl.setIcon(icon);
        }
    }//GEN-LAST:event_imgbrowseBtnActionPerformed
    public void Action() {

        itemnameTxt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt_code.requestFocusInWindow();
            }
        });

        txt_code.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                itempriceTxt.requestFocusInWindow();
            }
        });
        itempriceTxt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                itempurchasetxt.requestFocusInWindow();
            }
        });
        itempurchasetxt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                itemqty.requestFocusInWindow();
            }
        });
        itemqty.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                imgaddresssTxt.requestFocusInWindow();
            }
        });
        imgaddresssTxt.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                itemnameTxt.requestFocusInWindow();
            }
        });

    }
    private void itempriceTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itempriceTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itempriceTxtActionPerformed

    private void itempriceTxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itempriceTxtKeyTyped
        // TODO add your handling code here:

        checkInteger(itempriceTxt, evt);
    }//GEN-LAST:event_itempriceTxtKeyTyped

    private void itempurchasetxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itempurchasetxtKeyTyped
        // TODO add your handling code here:
        checkInteger(itempurchasetxt, evt);
    }//GEN-LAST:event_itempurchasetxtKeyTyped

    private void txt_codeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_codeKeyTyped
        // TODO add your handling code here:
        checkInteger(txt_code, evt);
    }//GEN-LAST:event_txt_codeKeyTyped

    private void itemqtyKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemqtyKeyTyped
        // TODO add your handling code here:
        checkInteger(itemqty, evt);
    }//GEN-LAST:event_itemqtyKeyTyped

    private void clearBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearBtn1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_clearBtn1MouseClicked

    private void clearBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtn1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
        SupplierView s = new SupplierView();
        s.setVisible(true);
    }//GEN-LAST:event_clearBtn1ActionPerformed
    public void checkInteger(JTextField txt, java.awt.event.KeyEvent evt) {
        String value = txt.getText();
        int l = value.length();
        if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyChar() == evt.VK_BACK_SPACE || evt.getKeyChar() == evt.VK_ENTER) {
            txt.setEditable(true);
        } else {
            txt.setEditable(false);
            JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Items().setVisible(true);

            }

        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JButton clearBtn;
    private javax.swing.JButton clearBtn1;
    private javax.swing.JLabel closeBtn;
    private javax.swing.JComboBox<String> combo_suppliername;
    private javax.swing.JButton createBtn;
    private javax.swing.JPanel dataPanel;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JPanel findPanel;
    private javax.swing.JLabel imgLbl;
    private javax.swing.JTextField imgaddresssTxt;
    private javax.swing.JButton imgbrowseBtn;
    private javax.swing.JPanel inputDataPanel;
    private javax.swing.JLabel itemidLbl;
    private javax.swing.JTextField itemnameTxt;
    private javax.swing.JTextField itempriceTxt;
    private javax.swing.JTextField itempurchasetxt;
    private javax.swing.JTextField itemqty;
    private javax.swing.JTable itemsTbl;
    private javax.swing.JLabel itmsLbl;
    private javax.swing.JLabel mainLbl;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JLabel searchLbl;
    private javax.swing.JLabel searchLbl1;
    private javax.swing.JLabel searchLbl2;
    private javax.swing.JLabel searchLbl4;
    private javax.swing.JLabel searchLbl6;
    private javax.swing.JLabel searchLbl7;
    private javax.swing.JLabel searchLbl8;
    private javax.swing.JLabel searchLbl9;
    private javax.swing.JTextField searchTxt;
    private javax.swing.JTextField txt_code;
    private javax.swing.JButton updateBtn;
    private javax.swing.JPanel viewPanel;
    // End of variables declaration//GEN-END:variables
}
