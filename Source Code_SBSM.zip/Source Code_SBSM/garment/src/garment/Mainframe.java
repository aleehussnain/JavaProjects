package garment;

import connection.DbConnection;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;


public class Mainframe extends javax.swing.JFrame {

    int disc = 0;
    static int id = 1;

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    HashMap prams;

    public Mainframe() {
        initComponents();
        Action();

        try {
            setIconImage(ImageIO.read(new File("gem_shop_icon.png")));
        } catch (IOException ex) {
            Logger.getLogger(Mainframe.class.getName()).log(Level.SEVERE, null, ex);
        }
        setTitle("AMANAT GARMENTS");
        //run db connection in constructor

        con = DbConnection.getConnection();
        show_date_time();
        //center window
        this.setLocationRelativeTo(null);

        //if (id == 1) {
        fill_Combo1();
        truncate_table_copy_mapping();
        //}

    }

    private void truncate_table_copy_mapping() {
        runI("truncate table copy_mapping");
    }

    private ResultSet runS(String q) {
        try {
            pst = con.prepareStatement(q);
            rs = pst.executeQuery();
            if (rs != null) {
                return rs;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }

    private boolean runI(String q) {
        try {
            pst = con.prepareStatement(q);
            pst.execute();
            return true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }

    public void Action() {

        txt_qty_sale.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt_discount.requestFocusInWindow();
            }
        });

        txt_discount.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt_qty_sale.requestFocusInWindow();
            }
        });

    }

    /*public void hide_User(String user, String userl) {
     if (userl.equalsIgnoreCase("cashier")) {
     retItembtn.setVisible(false);
     stockupdateBtn.setVisible(false);
     }

     setLogo(userl);
     jLabel4.setText(user);
     }*/
    public void fill_Combo1() {

        itmList.removeAllItems();
        //  discountTxt.removeAllItems();
        String loaddata;

        try {
            rs = runS("select sales_id from sales_item_mapping ORDER BY sales_id DESC;");
            if (rs.next()) {
                id = Integer.parseInt(rs.getString("sales_id")) + 1;

            } else {
                id = 1;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        try {

            rs = runS("SELECT item_name from items ");
            if (rs != null) {
                while (rs.next()) {
                    itmList.addItem(rs.getString("item_name"));
                    //  stockitemTxt.addItem(rs.getString("item_name"));
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

        //  discountTxt.addItem("No discount \\ 0 %");
    }

    private void setLabel() {

       // System.out.println(itmList.getSelectedItem());
        if (itmList.getSelectedItem()!=null) {
            String itemname = itmList.getSelectedItem().toString();
            try {
                rs = runS("SELECT s.qty,i.price,i.code FROM stocks as s inner join items as i on i.item_id = s.stock_id WHERE i.item_name='" + itemname + "'");
                if (rs.next()) {
                    itmpriceTxt.setText(rs.getString("price"));
                    qtystockTxt.setText(rs.getString("qty"));
                    txt_itemcode.setText(rs.getString("code"));
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Mainpanel = new javax.swing.JPanel();
        Topanel = new javax.swing.JPanel();
        SystemOption = new javax.swing.JPanel();
        minimizeBtn = new javax.swing.JLabel();
        closeBtn = new javax.swing.JLabel();
        CompanyDetails = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Datetime = new javax.swing.JPanel();
        timeLbl = new javax.swing.JLabel();
        dateLbl = new javax.swing.JLabel();
        logolbl = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        MidPanel = new javax.swing.JPanel();
        Maintasks = new javax.swing.JTabbedPane();
        Utilitypanel = new javax.swing.JPanel();
        utilitytitleLbl = new javax.swing.JLabel();
        utilitysubpanel = new javax.swing.JPanel();
        itemBtn = new javax.swing.JButton();
        itemtypeBtn = new javax.swing.JButton();
        calculatorBtn = new javax.swing.JButton();
        backupdbBtn = new javax.swing.JButton();
        retItembtn = new javax.swing.JButton();
        searchBillbtn = new javax.swing.JButton();
        Shoppanel = new javax.swing.JPanel();
        shopmainpanel = new javax.swing.JPanel();
        inputpanel = new javax.swing.JPanel();
        input = new javax.swing.JPanel();
        itmLbl = new javax.swing.JLabel();
        itmList = new javax.swing.JComboBox<>();
        qtyLbl = new javax.swing.JLabel();
        txt_qty_sale = new javax.swing.JTextField();
        qtyLbl1 = new javax.swing.JLabel();
        txt_itemcode = new javax.swing.JTextField();
        addBtn = new javax.swing.JButton();
        removeBtn = new javax.swing.JButton();
        discountLbl = new javax.swing.JLabel();
        txt_discount = new javax.swing.JTextField();
        removeBtn1 = new javax.swing.JButton();
        itemdetailspanel = new javax.swing.JPanel();
        qtystockLbl = new javax.swing.JLabel();
        qtystockTxt = new javax.swing.JLabel();
        itmpriceTxt = new javax.swing.JLabel();
        itmpriceLbl = new javax.swing.JLabel();
        imageLbl = new javax.swing.JLabel();
        billpanel = new javax.swing.JPanel();
        billtblpanel = new javax.swing.JScrollPane();
        billTbl = new javax.swing.JTable();
        cashpanel = new javax.swing.JPanel();
        totalLbl = new java.awt.Label();
        totalTxt = new java.awt.Label();
        paidLbl = new java.awt.Label();
        returnLbl = new java.awt.Label();
        paidTxt = new java.awt.TextField();
        returnTxt = new java.awt.Label();
        payBtn = new java.awt.Button();
        Stockpanel = new javax.swing.JPanel();
        stockmainpanel = new javax.swing.JPanel();
        stocktitleLbl = new javax.swing.JLabel();
        stocksubmainpanel = new javax.swing.JPanel();
        stockinputpanel = new javax.swing.JPanel();
        updateitemlist = new javax.swing.JLabel();
        stockitemLbl = new javax.swing.JLabel();
        stockqtyLbl = new javax.swing.JLabel();
        Item_name = new javax.swing.JTextField();
        itemQty = new javax.swing.JTextField();
        stockweightLbl = new javax.swing.JLabel();
        stockupdateBtn = new javax.swing.JButton();
        stockupdateBtn1 = new javax.swing.JButton();
        item_code = new javax.swing.JTextField();
        tblscrolpanel = new javax.swing.JScrollPane();
        stocktbl = new javax.swing.JTable();
        Reportpanel = new javax.swing.JPanel();
        reportsubpanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        dayendBtn = new javax.swing.JButton();
        salesreportLbl = new javax.swing.JLabel();
        weekendBtn = new javax.swing.JButton();
        monthendBtn = new javax.swing.JButton();
        yearendBtn = new javax.swing.JButton();
        salesBtn = new javax.swing.JButton();
        salesBtn1 = new javax.swing.JButton();
        topsellingpanel = new javax.swing.JPanel();
        topsellingitemLbl = new javax.swing.JLabel();
        topitem1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        topitemstbl = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        topitem4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        total_purchasetbl = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        topitem5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        soldtbl = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        reporttitleLbl = new javax.swing.JLabel();
        bottom = new javax.swing.JPanel();
        RavenSoftDesigns = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(new java.awt.Dimension(1366, 720));

        Mainpanel.setBackground(new java.awt.Color(0, 153, 153));
        Mainpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 10));
        Mainpanel.setPreferredSize(new java.awt.Dimension(1366, 720));

        Topanel.setBackground(new java.awt.Color(0, 153, 153));
        Topanel.setPreferredSize(new java.awt.Dimension(1366, 130));

        SystemOption.setBackground(new java.awt.Color(0, 153, 153));
        SystemOption.setForeground(new java.awt.Color(255, 255, 255));

        minimizeBtn.setBackground(new java.awt.Color(0, 153, 153));
        minimizeBtn.setFont(new java.awt.Font("Dialog", 1, 22)); // NOI18N
        minimizeBtn.setForeground(new java.awt.Color(255, 255, 255));
        minimizeBtn.setText("-");
        minimizeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeBtnMouseClicked(evt);
            }
        });

        closeBtn.setBackground(new java.awt.Color(0, 153, 153));
        closeBtn.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 255, 255));
        closeBtn.setText("X");
        closeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout SystemOptionLayout = new javax.swing.GroupLayout(SystemOption);
        SystemOption.setLayout(SystemOptionLayout);
        SystemOptionLayout.setHorizontalGroup(
            SystemOptionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SystemOptionLayout.createSequentialGroup()
                .addComponent(minimizeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(closeBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE))
        );
        SystemOptionLayout.setVerticalGroup(
            SystemOptionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SystemOptionLayout.createSequentialGroup()
                .addGroup(SystemOptionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(minimizeBtn)
                    .addComponent(closeBtn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        CompanyDetails.setBackground(new java.awt.Color(0, 153, 153));
        CompanyDetails.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 40)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("JOHN GARMENTS");

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Umer Sarfraz ");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("1829451");

        javax.swing.GroupLayout CompanyDetailsLayout = new javax.swing.GroupLayout(CompanyDetails);
        CompanyDetails.setLayout(CompanyDetailsLayout);
        CompanyDetailsLayout.setHorizontalGroup(
            CompanyDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CompanyDetailsLayout.createSequentialGroup()
                .addGroup(CompanyDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(CompanyDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        CompanyDetailsLayout.setVerticalGroup(
            CompanyDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CompanyDetailsLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(0, 20, Short.MAX_VALUE))
        );

        Datetime.setBackground(new java.awt.Color(0, 153, 153));
        Datetime.setForeground(new java.awt.Color(255, 255, 255));

        timeLbl.setBackground(new java.awt.Color(0, 153, 153));
        timeLbl.setFont(new java.awt.Font("Digital-7 Mono", 1, 18)); // NOI18N
        timeLbl.setForeground(new java.awt.Color(255, 255, 255));
        timeLbl.setText("12:00 PM");

        dateLbl.setBackground(new java.awt.Color(0, 153, 153));
        dateLbl.setFont(new java.awt.Font("Digital-7 Mono", 1, 18)); // NOI18N
        dateLbl.setForeground(new java.awt.Color(255, 255, 255));
        dateLbl.setText("06/12/2020");

        javax.swing.GroupLayout DatetimeLayout = new javax.swing.GroupLayout(Datetime);
        Datetime.setLayout(DatetimeLayout);
        DatetimeLayout.setHorizontalGroup(
            DatetimeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DatetimeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(timeLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dateLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        DatetimeLayout.setVerticalGroup(
            DatetimeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DatetimeLayout.createSequentialGroup()
                .addGroup(DatetimeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        logolbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/admin.png"))); // NOI18N

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Amanat");

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/gem_shop_icon.png"))); // NOI18N

        javax.swing.GroupLayout TopanelLayout = new javax.swing.GroupLayout(Topanel);
        Topanel.setLayout(TopanelLayout);
        TopanelLayout.setHorizontalGroup(
            TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(CompanyDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TopanelLayout.createSequentialGroup()
                        .addGroup(TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Datetime, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SystemOption, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TopanelLayout.createSequentialGroup()
                        .addGroup(TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(logolbl, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(127, 127, 127))))
        );
        TopanelLayout.setVerticalGroup(
            TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TopanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(CompanyDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(TopanelLayout.createSequentialGroup()
                        .addGroup(TopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(SystemOption, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(logolbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(10, 10, 10)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Datetime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Maintasks.setBackground(new java.awt.Color(255, 255, 255));
        Maintasks.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(255, 255, 255), null));
        Maintasks.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N

        Utilitypanel.setBackground(new java.awt.Color(204, 204, 255));
        Utilitypanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        utilitytitleLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        utilitytitleLbl.setText("UTILITIES");

        utilitysubpanel.setBackground(new java.awt.Color(204, 204, 255));
        utilitysubpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        itemBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/item.png"))); // NOI18N
        itemBtn.setText("ITEM");
        itemBtn.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        itemBtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        itemBtn.setIconTextGap(30);
        itemBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBtnActionPerformed(evt);
            }
        });

        itemtypeBtn.setForeground(new java.awt.Color(0, 51, 51));
        itemtypeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/item.png"))); // NOI18N
        itemtypeBtn.setText("Suppliers");
        itemtypeBtn.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        itemtypeBtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        itemtypeBtn.setIconTextGap(20);
        itemtypeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemtypeBtnMouseClicked(evt);
            }
        });
        itemtypeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtypeBtnActionPerformed(evt);
            }
        });

        calculatorBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cal.png"))); // NOI18N
        calculatorBtn.setText("CALCULATOR");
        calculatorBtn.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        calculatorBtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        calculatorBtn.setIconTextGap(15);
        calculatorBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                calculatorBtnMouseClicked(evt);
            }
        });

        backupdbBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/backup.png"))); // NOI18N
        backupdbBtn.setText("BACKUP");
        backupdbBtn.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        backupdbBtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        backupdbBtn.setIconTextGap(30);
        backupdbBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backupdbBtnMouseClicked(evt);
            }
        });
        backupdbBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backupdbBtnActionPerformed(evt);
            }
        });

        retItembtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/returnitem.png"))); // NOI18N
        retItembtn.setText("Return Item");
        retItembtn.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        retItembtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        retItembtn.setIconTextGap(15);
        retItembtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                retItembtnMouseClicked(evt);
            }
        });
        retItembtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retItembtnActionPerformed(evt);
            }
        });

        searchBillbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/billsearch.png"))); // NOI18N
        searchBillbtn.setText("Search Bill");
        searchBillbtn.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        searchBillbtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        searchBillbtn.setIconTextGap(15);
        searchBillbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchBillbtnMouseClicked(evt);
            }
        });
        searchBillbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBillbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout utilitysubpanelLayout = new javax.swing.GroupLayout(utilitysubpanel);
        utilitysubpanel.setLayout(utilitysubpanelLayout);
        utilitysubpanelLayout.setHorizontalGroup(
            utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(utilitysubpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(itemBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(retItembtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(calculatorBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(86, 86, 86)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(backupdbBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itemtypeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBillbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(798, Short.MAX_VALUE))
        );
        utilitysubpanelLayout.setVerticalGroup(
            utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(utilitysubpanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itemBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itemtypeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backupdbBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(calculatorBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(utilitysubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(retItembtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBillbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(105, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout UtilitypanelLayout = new javax.swing.GroupLayout(Utilitypanel);
        Utilitypanel.setLayout(UtilitypanelLayout);
        UtilitypanelLayout.setHorizontalGroup(
            UtilitypanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UtilitypanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(UtilitypanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(utilitysubpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(utilitytitleLbl))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        UtilitypanelLayout.setVerticalGroup(
            UtilitypanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UtilitypanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(utilitytitleLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(utilitysubpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Maintasks.addTab("HOME                       ", Utilitypanel);

        Shoppanel.setBackground(new java.awt.Color(0, 153, 153));
        Shoppanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        shopmainpanel.setBackground(new java.awt.Color(204, 204, 255));
        shopmainpanel.setPreferredSize(new java.awt.Dimension(1305, 405));

        inputpanel.setBackground(new java.awt.Color(204, 204, 255));
        inputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        inputpanel.setPreferredSize(new java.awt.Dimension(655, 100));

        input.setBackground(new java.awt.Color(204, 204, 255));

        itmLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        itmLbl.setText("ITEM Name:");

        itmList.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                itmListPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        itmList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                itmListMouseEntered(evt);
            }
        });

        qtyLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        qtyLbl.setText("QUANTITY:");

        txt_qty_sale.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_qty_saleKeyTyped(evt);
            }
        });

        qtyLbl1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        qtyLbl1.setText("Item Code:");

        txt_itemcode.setEditable(false);

        addBtn.setBackground(new java.awt.Color(102, 255, 102));
        addBtn.setText("ADD TO CART");
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });
        addBtn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                addBtnKeyTyped(evt);
            }
        });

        removeBtn.setBackground(new java.awt.Color(255, 102, 102));
        removeBtn.setText("REMOVE FROM CART");
        removeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeBtnActionPerformed(evt);
            }
        });

        discountLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        discountLbl.setText("DISCOUNT:");

        txt_discount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_discountKeyTyped(evt);
            }
        });

        removeBtn1.setBackground(new java.awt.Color(255, 51, 0));
        removeBtn1.setForeground(new java.awt.Color(255, 255, 255));
        removeBtn1.setText("CANCEL ORDER");
        removeBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout inputLayout = new javax.swing.GroupLayout(input);
        input.setLayout(inputLayout);
        inputLayout.setHorizontalGroup(
            inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inputLayout.createSequentialGroup()
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, inputLayout.createSequentialGroup()
                        .addComponent(qtyLbl1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_itemcode, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, inputLayout.createSequentialGroup()
                        .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(qtyLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(itmLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(discountLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inputLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_discount, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                                    .addComponent(txt_qty_sale)))
                            .addGroup(inputLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(itmList, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(inputLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(removeBtn1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(removeBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(82, 82, 82))
        );
        inputLayout.setVerticalGroup(
            inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputLayout.createSequentialGroup()
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itmList, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itmLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(qtyLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_itemcode, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(qtyLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(txt_qty_sale))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_discount, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(discountLbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(inputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inputLayout.createSequentialGroup()
                        .addComponent(removeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(removeBtn1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(addBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        itemdetailspanel.setBackground(new java.awt.Color(204, 204, 255));

        qtystockLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        qtystockLbl.setText("AVAILABLE :");

        qtystockTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        qtystockTxt.setForeground(new java.awt.Color(0, 102, 0));

        itmpriceTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        itmpriceTxt.setForeground(new java.awt.Color(0, 102, 0));

        itmpriceLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        itmpriceLbl.setText("ITEM PRICE :");

        javax.swing.GroupLayout itemdetailspanelLayout = new javax.swing.GroupLayout(itemdetailspanel);
        itemdetailspanel.setLayout(itemdetailspanelLayout);
        itemdetailspanelLayout.setHorizontalGroup(
            itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(itemdetailspanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(itemdetailspanelLayout.createSequentialGroup()
                        .addComponent(qtystockLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(qtystockTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 30, Short.MAX_VALUE))
                    .addGroup(itemdetailspanelLayout.createSequentialGroup()
                        .addComponent(itmpriceLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(itmpriceTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(42, 42, 42))
        );
        itemdetailspanelLayout.setVerticalGroup(
            itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, itemdetailspanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(itmpriceTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itmpriceLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(itemdetailspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(qtystockLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(qtystockTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13))
        );

        imageLbl.setBackground(new java.awt.Color(255, 255, 204));
        imageLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/diamond.png"))); // NOI18N

        javax.swing.GroupLayout inputpanelLayout = new javax.swing.GroupLayout(inputpanel);
        inputpanel.setLayout(inputpanelLayout);
        inputpanelLayout.setHorizontalGroup(
            inputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputpanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(input, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(imageLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itemdetailspanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        inputpanelLayout.setVerticalGroup(
            inputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inputpanelLayout.createSequentialGroup()
                .addGroup(inputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(inputpanelLayout.createSequentialGroup()
                        .addComponent(itemdetailspanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(imageLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(inputpanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(input, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        billpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        billtblpanel.setBackground(new java.awt.Color(153, 204, 255));

        billTbl.setBackground(new java.awt.Color(204, 204, 204));
        billTbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        billTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Item name", "item price", "qty", "weight", "discount", "sub-total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        billTbl.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        billTbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        billTbl.setShowHorizontalLines(false);
        billTbl.getTableHeader().setReorderingAllowed(false);
        billtblpanel.setViewportView(billTbl);

        javax.swing.GroupLayout billpanelLayout = new javax.swing.GroupLayout(billpanel);
        billpanel.setLayout(billpanelLayout);
        billpanelLayout.setHorizontalGroup(
            billpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(billtblpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                .addContainerGap())
        );
        billpanelLayout.setVerticalGroup(
            billpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(billtblpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        cashpanel.setBackground(new java.awt.Color(204, 204, 255));
        cashpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        cashpanel.setPreferredSize(new java.awt.Dimension(1281, 141));

        totalLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        totalLbl.setText("Total Amount :");

        totalTxt.setAlignment(java.awt.Label.CENTER);
        totalTxt.setBackground(new java.awt.Color(204, 204, 255));
        totalTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        totalTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        totalTxt.setForeground(new java.awt.Color(51, 51, 255));
        totalTxt.setText("0000.00");

        paidLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        paidLbl.setText("Collected Amount :");

        returnLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        returnLbl.setText("Return Amount      :");

        paidTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        paidTxt.setForeground(new java.awt.Color(51, 51, 255));
        paidTxt.setText("0");
        paidTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paidTxtActionPerformed(evt);
            }
        });

        returnTxt.setBackground(new java.awt.Color(255, 255, 255));
        returnTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        returnTxt.setForeground(new java.awt.Color(0, 153, 0));
        returnTxt.setText("0000.00");

        payBtn.setBackground(new java.awt.Color(255, 102, 102));
        payBtn.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        payBtn.setForeground(new java.awt.Color(255, 255, 255));
        payBtn.setLabel("PAY");
        payBtn.setName(""); // NOI18N
        payBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cashpanelLayout = new javax.swing.GroupLayout(cashpanel);
        cashpanel.setLayout(cashpanelLayout);
        cashpanelLayout.setHorizontalGroup(
            cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cashpanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(totalLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addComponent(totalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(230, 230, 230)
                .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(cashpanelLayout.createSequentialGroup()
                        .addComponent(returnLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(returnTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(cashpanelLayout.createSequentialGroup()
                        .addComponent(paidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(paidTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(payBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        cashpanelLayout.setVerticalGroup(
            cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cashpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(payBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(cashpanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(totalLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(cashpanelLayout.createSequentialGroup()
                                .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(paidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(paidTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(cashpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(returnLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(returnTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(totalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(216, 216, 216))
        );

        javax.swing.GroupLayout shopmainpanelLayout = new javax.swing.GroupLayout(shopmainpanel);
        shopmainpanel.setLayout(shopmainpanelLayout);
        shopmainpanelLayout.setHorizontalGroup(
            shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(shopmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cashpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1285, Short.MAX_VALUE)
                    .addGroup(shopmainpanelLayout.createSequentialGroup()
                        .addComponent(inputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(billpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        shopmainpanelLayout.setVerticalGroup(
            shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(shopmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(shopmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(billpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(inputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 311, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cashpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout ShoppanelLayout = new javax.swing.GroupLayout(Shoppanel);
        Shoppanel.setLayout(ShoppanelLayout);
        ShoppanelLayout.setHorizontalGroup(
            ShoppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ShoppanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(shopmainpanel, 1315, 1315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        ShoppanelLayout.setVerticalGroup(
            ShoppanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ShoppanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(shopmainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE)
                .addContainerGap())
        );

        Maintasks.addTab("JOHN SHOP              ", Shoppanel);

        Stockpanel.setBackground(new java.awt.Color(204, 204, 255));
        Stockpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        stockmainpanel.setBackground(new java.awt.Color(204, 204, 255));
        stockmainpanel.setPreferredSize(new java.awt.Dimension(1305, 405));

        stocktitleLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stocktitleLbl.setText("STOCK MANAGEMENT");

        stocksubmainpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 204, 255), null));

        stockinputpanel.setBackground(new java.awt.Color(204, 204, 255));
        stockinputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        updateitemlist.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        updateitemlist.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        updateitemlist.setText("UPDATE ITEM STOCK");

        stockitemLbl.setFont(new java.awt.Font("Gadugi", 1, 13)); // NOI18N
        stockitemLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        stockitemLbl.setText("Item Code");

        stockqtyLbl.setFont(new java.awt.Font("Gadugi", 1, 13)); // NOI18N
        stockqtyLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        stockqtyLbl.setText("Item Name");

        Item_name.setEditable(false);

        itemQty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemQtyKeyTyped(evt);
            }
        });

        stockweightLbl.setFont(new java.awt.Font("Gadugi", 1, 13)); // NOI18N
        stockweightLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        stockweightLbl.setText("Qty");

        stockupdateBtn.setBackground(new java.awt.Color(0, 153, 0));
        stockupdateBtn.setForeground(new java.awt.Color(255, 255, 255));
        stockupdateBtn.setText("UPDATE");
        stockupdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockupdateBtnActionPerformed(evt);
            }
        });

        stockupdateBtn1.setText("Load Data");
        stockupdateBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockupdateBtn1ActionPerformed(evt);
            }
        });

        item_code.setEditable(false);

        javax.swing.GroupLayout stockinputpanelLayout = new javax.swing.GroupLayout(stockinputpanel);
        stockinputpanel.setLayout(stockinputpanelLayout);
        stockinputpanelLayout.setHorizontalGroup(
            stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockinputpanelLayout.createSequentialGroup()
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(stockinputpanelLayout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(stockinputpanelLayout.createSequentialGroup()
                                .addComponent(stockweightLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(itemQty, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(stockinputpanelLayout.createSequentialGroup()
                                    .addComponent(stockitemLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(item_code, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, stockinputpanelLayout.createSequentialGroup()
                                    .addComponent(stockqtyLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(stockupdateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(Item_name, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE))))))
                    .addGroup(stockinputpanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(stockupdateBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(updateitemlist, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(156, Short.MAX_VALUE))
        );
        stockinputpanelLayout.setVerticalGroup(
            stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockinputpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateitemlist, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stockupdateBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stockitemLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(item_code, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Item_name, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stockqtyLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(stockinputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itemQty, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stockweightLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(stockupdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(137, Short.MAX_VALUE))
        );

        tblscrolpanel.setBackground(new java.awt.Color(153, 204, 255));

        stocktbl.setBackground(new java.awt.Color(204, 204, 204));
        stocktbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        stocktbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "ITEM NAME", "ITEM CODE", "QTY", "WEIGHT", "LAST UPDATE", "STATE"
            }
        ));
        stocktbl.setGridColor(new java.awt.Color(204, 204, 255));
        stocktbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        stocktbl.setSelectionForeground(new java.awt.Color(51, 51, 51));
        stocktbl.setShowHorizontalLines(false);
        stocktbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stocktblMouseClicked(evt);
            }
        });
        stocktbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                stocktblKeyReleased(evt);
            }
        });
        tblscrolpanel.setViewportView(stocktbl);

        javax.swing.GroupLayout stocksubmainpanelLayout = new javax.swing.GroupLayout(stocksubmainpanel);
        stocksubmainpanel.setLayout(stocksubmainpanelLayout);
        stocksubmainpanelLayout.setHorizontalGroup(
            stocksubmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stocksubmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(stockinputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tblscrolpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 627, Short.MAX_VALUE)
                .addContainerGap())
        );
        stocksubmainpanelLayout.setVerticalGroup(
            stocksubmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stocksubmainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(stocksubmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(stockinputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tblscrolpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout stockmainpanelLayout = new javax.swing.GroupLayout(stockmainpanel);
        stockmainpanel.setLayout(stockmainpanelLayout);
        stockmainpanelLayout.setHorizontalGroup(
            stockmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockmainpanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(stockmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(stocktitleLbl)
                    .addComponent(stocksubmainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        stockmainpanelLayout.setVerticalGroup(
            stockmainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(stockmainpanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(stocktitleLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(stocksubmainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout StockpanelLayout = new javax.swing.GroupLayout(Stockpanel);
        Stockpanel.setLayout(StockpanelLayout);
        StockpanelLayout.setHorizontalGroup(
            StockpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(StockpanelLayout.createSequentialGroup()
                .addComponent(stockmainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        StockpanelLayout.setVerticalGroup(
            StockpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(stockmainpanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 474, Short.MAX_VALUE)
        );

        Maintasks.addTab("STOCKS                                 ", Stockpanel);

        Reportpanel.setBackground(new java.awt.Color(204, 204, 255));
        Reportpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        reportsubpanel.setBackground(new java.awt.Color(255, 255, 255));
        reportsubpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        dayendBtn.setText("DAY END REPORT");
        dayendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dayendBtnActionPerformed(evt);
            }
        });

        salesreportLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        salesreportLbl.setText("SALES REPORTS");

        weekendBtn.setText("WEEK END REPORT");
        weekendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weekendBtnActionPerformed(evt);
            }
        });

        monthendBtn.setText("MONTH END REPORT");
        monthendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthendBtnActionPerformed(evt);
            }
        });

        yearendBtn.setText("YEAR END REPORT");
        yearendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearendBtnActionPerformed(evt);
            }
        });

        salesBtn.setText("SALES");
        salesBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salesBtnActionPerformed(evt);
            }
        });

        salesBtn1.setText("Clear");
        salesBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                salesBtn1MouseClicked(evt);
            }
        });
        salesBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salesBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salesreportLbl)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(monthendBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dayendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yearendBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(salesBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(salesBtn1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(46, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(36, 36, 36)
                    .addComponent(weekendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(45, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(salesreportLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dayendBtn)
                .addGap(38, 38, 38)
                .addComponent(monthendBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yearendBtn)
                .addGap(30, 30, 30)
                .addComponent(salesBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(salesBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(93, 93, 93)
                    .addComponent(weekendBtn)
                    .addContainerGap(263, Short.MAX_VALUE)))
        );

        topsellingpanel.setBackground(new java.awt.Color(204, 204, 255));
        topsellingpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        topsellingitemLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        topsellingitemLbl.setText("TOP SELLING ITEMS");

        topitem1.setBorder(new javax.swing.border.MatteBorder(null));

        topitemstbl.setBackground(new java.awt.Color(204, 204, 204));
        topitemstbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        topitemstbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        topitemstbl.setGridColor(new java.awt.Color(204, 204, 204));
        topitemstbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        topitemstbl.setSelectionForeground(new java.awt.Color(0, 0, 0));
        topitemstbl.setShowHorizontalLines(false);
        jScrollPane2.setViewportView(topitemstbl);

        jLabel5.setBackground(new java.awt.Color(255, 255, 0));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Top 5 most selling items");

        javax.swing.GroupLayout topitem1Layout = new javax.swing.GroupLayout(topitem1);
        topitem1.setLayout(topitem1Layout);
        topitem1Layout.setHorizontalGroup(
            topitem1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, topitem1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(21, 21, 21))
            .addGroup(topitem1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        topitem1Layout.setVerticalGroup(
            topitem1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, topitem1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        topitem4.setBorder(new javax.swing.border.MatteBorder(null));

        total_purchasetbl.setBackground(new java.awt.Color(204, 204, 204));
        total_purchasetbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        total_purchasetbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        total_purchasetbl.setGridColor(new java.awt.Color(204, 204, 204));
        total_purchasetbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        total_purchasetbl.setSelectionForeground(new java.awt.Color(0, 0, 0));
        total_purchasetbl.setShowHorizontalLines(false);
        jScrollPane3.setViewportView(total_purchasetbl);

        jLabel7.setBackground(new java.awt.Color(255, 255, 0));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Item Sale Records");

        javax.swing.GroupLayout topitem4Layout = new javax.swing.GroupLayout(topitem4);
        topitem4.setLayout(topitem4Layout);
        topitem4Layout.setHorizontalGroup(
            topitem4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topitem4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, topitem4Layout.createSequentialGroup()
                .addContainerGap(89, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(76, 76, 76))
        );
        topitem4Layout.setVerticalGroup(
            topitem4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, topitem4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        topitem5.setBorder(new javax.swing.border.MatteBorder(null));

        soldtbl.setBackground(new java.awt.Color(204, 204, 204));
        soldtbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        soldtbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        soldtbl.setGridColor(new java.awt.Color(204, 204, 204));
        soldtbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        soldtbl.setSelectionForeground(new java.awt.Color(0, 0, 0));
        soldtbl.setShowHorizontalLines(false);
        jScrollPane4.setViewportView(soldtbl);

        jLabel6.setBackground(new java.awt.Color(255, 255, 0));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Overall selling History");

        javax.swing.GroupLayout topitem5Layout = new javax.swing.GroupLayout(topitem5);
        topitem5.setLayout(topitem5Layout);
        topitem5Layout.setHorizontalGroup(
            topitem5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topitem5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(topitem5Layout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addComponent(jLabel6)
                .addContainerGap(144, Short.MAX_VALUE))
        );
        topitem5Layout.setVerticalGroup(
            topitem5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, topitem5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout topsellingpanelLayout = new javax.swing.GroupLayout(topsellingpanel);
        topsellingpanel.setLayout(topsellingpanelLayout);
        topsellingpanelLayout.setHorizontalGroup(
            topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topsellingpanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(topsellingitemLbl)
                    .addGroup(topsellingpanelLayout.createSequentialGroup()
                        .addComponent(topitem1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(topitem5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(topitem4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        topsellingpanelLayout.setVerticalGroup(
            topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topsellingpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(topsellingitemLbl)
                .addGap(35, 35, 35)
                .addGroup(topsellingpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(topitem4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(topitem1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(topitem5, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout reportsubpanelLayout = new javax.swing.GroupLayout(reportsubpanel);
        reportsubpanel.setLayout(reportsubpanelLayout);
        reportsubpanelLayout.setHorizontalGroup(
            reportsubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportsubpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(topsellingpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        reportsubpanelLayout.setVerticalGroup(
            reportsubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reportsubpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(reportsubpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(topsellingpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        reporttitleLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        reporttitleLbl.setText("REPORTS");

        javax.swing.GroupLayout ReportpanelLayout = new javax.swing.GroupLayout(Reportpanel);
        Reportpanel.setLayout(ReportpanelLayout);
        ReportpanelLayout.setHorizontalGroup(
            ReportpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportpanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(reporttitleLbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ReportpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(reportsubpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        ReportpanelLayout.setVerticalGroup(
            ReportpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReportpanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(reporttitleLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reportsubpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Maintasks.addTab("REPORTS                                ", Reportpanel);

        javax.swing.GroupLayout MidPanelLayout = new javax.swing.GroupLayout(MidPanel);
        MidPanel.setLayout(MidPanelLayout);
        MidPanelLayout.setHorizontalGroup(
            MidPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Maintasks, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        MidPanelLayout.setVerticalGroup(
            MidPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MidPanelLayout.createSequentialGroup()
                .addComponent(Maintasks, javax.swing.GroupLayout.PREFERRED_SIZE, 518, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
        );

        bottom.setBackground(new java.awt.Color(255, 255, 255));
        bottom.setToolTipText("");
        bottom.setPreferredSize(new java.awt.Dimension(1366, 40));

        RavenSoftDesigns.setBackground(new java.awt.Color(0, 153, 153));
        RavenSoftDesigns.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        RavenSoftDesigns.setText("© TechCrow pvt ltd - 03046069435");

        javax.swing.GroupLayout bottomLayout = new javax.swing.GroupLayout(bottom);
        bottom.setLayout(bottomLayout);
        bottomLayout.setHorizontalGroup(
            bottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bottomLayout.createSequentialGroup()
                .addContainerGap(538, Short.MAX_VALUE)
                .addComponent(RavenSoftDesigns, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(499, 499, 499))
        );
        bottomLayout.setVerticalGroup(
            bottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bottomLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RavenSoftDesigns)
                .addContainerGap())
        );

        javax.swing.GroupLayout MainpanelLayout = new javax.swing.GroupLayout(Mainpanel);
        Mainpanel.setLayout(MainpanelLayout);
        MainpanelLayout.setHorizontalGroup(
            MainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MidPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(2, 2, 2))
            .addComponent(bottom, javax.swing.GroupLayout.DEFAULT_SIZE, 1334, Short.MAX_VALUE)
            .addComponent(Topanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1334, Short.MAX_VALUE)
        );
        MainpanelLayout.setVerticalGroup(
            MainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainpanelLayout.createSequentialGroup()
                .addComponent(Topanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(MidPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bottom, 36, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1354, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(Mainpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeBtnMouseClicked
        // close btn:
        System.exit(0);
    }//GEN-LAST:event_closeBtnMouseClicked

    private void minimizeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeBtnMouseClicked
        // minimize btn:
        this.setState(Mainframe.ICONIFIED);

    }//GEN-LAST:event_minimizeBtnMouseClicked
    private void clearfields() {
        txt_discount.setText("");
        itmpriceTxt.setText("");
        itmList.setSelectedItem("");
        txt_qty_sale.setText("");
        txt_itemcode.setText("");
        //discountTxt.setSelectedItem("");
        qtystockTxt.setText("");

        // showweighttxt.setText("");
    }

    private void clearme() {
        paidTxt.setText("");
        returnTxt.setText("");
        totalTxt.setText("");
        this.disc = 0;
    }
    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        // TODO add your handling code here:

        if (txt_qty_sale.getText().equals("") || txt_discount.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter Qty and Discount!");

        } else {
            if (Integer.parseInt(txt_qty_sale.getText()) < Integer.parseInt(qtystockTxt.getText())
                    && Integer.parseInt(txt_discount.getText()) < Integer.parseInt(itmpriceTxt.getText())) {
                try {
                    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                    int qty = Integer.parseInt(txt_qty_sale.getText());
                    String name = itmList.getSelectedItem().toString();
                    String code = txt_itemcode.getText();
                    String total = String.valueOf(Double.parseDouble(itmpriceTxt.getText()) * qty);
                    if (runI("INSERT INTO `copy_mapping`(`sales_id`, `item_name`,item_code, `price`, `qty`, `discount`, `total`,date_sold) VALUES ("
                            + "'" + id + "','" + name + "'," + code + ",'" + itmpriceTxt.getText() + "','" + txt_qty_sale.getText() + "','" + txt_discount.getText() + "','" + total + "','" + timestamp + "')")) {
                        stockUpdate1(qty, code, name);
                        set_totalAmmount();
                        setDiscount(Integer.parseInt(txt_discount.getText()));
                    }

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);

                }

                loadTable1();

                clearfields();

            } else {
                JOptionPane.showMessageDialog(this, "Quantity or Discount is invalid !");
            }
        }

    }//GEN-LAST:event_addBtnActionPerformed
    public void setDiscount(int discc) {
        this.disc += discc;
    }
    private void paidTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paidTxtActionPerformed
        returnTxt.setText(String.valueOf(Double.parseDouble(paidTxt.getText()) - Double.parseDouble(totalTxt.getText())));
    }//GEN-LAST:event_paidTxtActionPerformed

    private void payBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payBtnActionPerformed
        if (!paidTxt.getText().equals("")) {
            if ((Double.parseDouble(paidTxt.getText()) >= Double.parseDouble(totalTxt.getText()))) {
                returnTxt.setText((Double.parseDouble(paidTxt.getText()) - Double.parseDouble(totalTxt.getText())) + "");
                fill_Combo1();
                call_replicaterecords();
                truncate_table_copy_mapping();
                fill_newRecieptTable();
                callReceipt();
                DefaultTableModel model = (DefaultTableModel) billTbl.getModel();
                model.setRowCount(0);
                clearfields();
                clearme();

                setid();
            } else {
                JOptionPane.showMessageDialog(null, "Collected amount is less then Total bill!");
            }

        } else {
            JOptionPane.showMessageDialog(null, "Collected amount can not empty!");
        }


    }//GEN-LAST:event_payBtnActionPerformed
    private void call_replicaterecords() {
        rs = runS("select * from copy_mapping");
        try {
            if (rs != null) {
                while (rs.next()) {
                    String idd = rs.getString("sales_id");
                    String namee = rs.getString("item_name");
                    String codee = rs.getString("item_code");
                    String pricee = rs.getString("price");
                    String qtyy = rs.getString("qty");
                    String discountt = rs.getString("discount");
                    String totall = rs.getString("total");
                    String datee = rs.getString("date_sold");

                    if (runI("INSERT INTO `sales_item_mapping`(`sales_id`, `item_name`, `item_code`, `price`, `qty`, `discount`, `total`, `date_sold`) VALUES ('" + idd + "','" + namee + "','" + codee + "','" + pricee + "','" + qtyy + "','" + discountt + "','" + totall + "','" + datee + "')")) {

                    } else {
                        JOptionPane.showMessageDialog(null, "replicating the insertion data in sales_mapping ");

                    }
                }

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    private void setid() {

        try {
            rs = runS("select sales_id from sales_item_mapping ORDER BY sales_id DESC;");
            if (rs.next()) {
                id = Integer.parseInt(rs.getString("sales_id")) + 1;

                runI("TRUNCATE TABLE sales");
                disc = 0;

            } else {
                id = 1;
                disc = 0;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    private void fill_newRecieptTable() {
        if (runI("TRUNCATE TABLE sales")) {
            runI("INSERT INTO sales (sale_Id,name, Qty, price,total)\n"
                    + "SELECT m.sales_id, m.item_name, m.Qty, m.price, m.total FROM sales_item_mapping as m \n"
                    + "WHERE m.sales_id=(select max( sales_id) from sales_item_mapping);");
        }

    } private void stockupdateBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockupdateBtn1ActionPerformed
            // TODO add your handling code here:
            loadTable();
    }//GEN-LAST:event_stockupdateBtn1ActionPerformed

    public void con() {
        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/garments", "root", "root");
//            con = DriverManager.getConnection(dbhost, user, password);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            System.err.println("error in connection");
            e.printStackTrace();
        }
    }

    public void JesperReport() {

        try {
            JasperDesign jd = JRXmlLoader.load("src/report/JasperReportReceipt.jrxml");
            String query = "select * from sales";
            JRDesignQuery updatequery = new JRDesignQuery();
            updatequery.setText(query);
            jd.setQuery(updatequery);
            JasperReport jesperReport = JasperCompileManager.compileReport(jd);
            JasperPrint jprint = JasperFillManager.fillReport(jesperReport, prams, con);
            JasperPrintManager.printReport(jprint, true);
           // JasperViewer.viewReport(jprint);
            //runI("truncate table sales");
        } catch (JRException ex) {
            Logger.getLogger(Mainframe.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void setTotal(String id) {
        try {
            //String loaddata = "select stu_id as ID,stu_name as Name,stu_age as Age,stu_grade as Grade from student";
            rs = runS("select sum(s.price*s.qty)as total from sales_item_mapping as s where s.sales_id='" + id + "'");
            if (rs.next()) {
                prams.put("totall", rs.getString("total"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    private void callReceipt() {
        prams = new HashMap();
        String date = dateLbl.getText() + "  " + timeLbl.getText();
        prams.put("date", date);
        prams.put("receipt", id + "");
        prams.put("discount", disc + "");
        prams.put("grand", totalTxt.getText());
        prams.put("round", "0.0");
       // setTotal(id + "");
        prams.put("totall", (disc + (Integer.parseInt(totalTxt.getText()))) + "");
        prams.put("printed", jLabel4.getText());
        prams.put("nett", paidTxt.getText());
        prams.put("change", returnTxt.getText());
        prams.put("tendered", "0.00");
        JesperReport();
    }
    private void weekendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weekendBtnActionPerformed
        loadTopitemstbl(7 + "");
        loadSoldItemtbl(7 + "");
        loadTopPurchase(7 + "");
    }//GEN-LAST:event_weekendBtnActionPerformed

    private void monthendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthendBtnActionPerformed
        loadTopitemstbl(30 + "");        // TODO add your handling code here:
        loadSoldItemtbl(30 + "");
        loadTopPurchase(30 + "");
    }//GEN-LAST:event_monthendBtnActionPerformed

    private void yearendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearendBtnActionPerformed
        // TODO add your handling code here:
        loadTopitemstbl(365 + "");
        loadSoldItemtbl(365 + "");
        loadTopPurchase(365 + "");
    }//GEN-LAST:event_yearendBtnActionPerformed

    private void salesBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salesBtnActionPerformed
        // TODO add your handling code here:
        // loadTopitemstblAll();
        loadsale_productRecords_tbl();
    }//GEN-LAST:event_salesBtnActionPerformed
    private void loadsale_productRecords_tbl() {
        rs = runS("SELECT i.supplier,s.item_code as code,i.item_name as name,s.total_qty as qty, s.total_qty-s.qty as sold\n"
                + "from stocks s inner join items i on s.stock_id=i.item_id ORDER by i.supplier");
        soldtbl.setModel(DbUtils.resultSetToTableModel(rs));
    }
    private void itemBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBtnActionPerformed
        // Itemsbtn
        this.dispose();
        Items items = new Items();
        items.setVisible(true);
        //items.setUndecorated(true);
        //setUndecorated(true);
    }//GEN-LAST:event_itemBtnActionPerformed

    private void itemtypeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemtypeBtnMouseClicked
        // Titemtypes:
        // Itemtypes itemtypes = new Itemtypes();
        // itemtypes.setVisible(true);
    }//GEN-LAST:event_itemtypeBtnMouseClicked

    private void calculatorBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_calculatorBtnMouseClicked
        // TODO add your handling code here:
        Calculator calculator = new Calculator();
        calculator.setVisible(true);
    }//GEN-LAST:event_calculatorBtnMouseClicked

    private void backupdbBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backupdbBtnMouseClicked
        // TODO add your handling code here:
        Backups backups = new Backups();
        backups.setVisible(true);
    }//GEN-LAST:event_backupdbBtnMouseClicked

    private void backupdbBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backupdbBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_backupdbBtnActionPerformed

    private void dayendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dayendBtnActionPerformed
        // TODO add your handling code here:
        loadTopitemstbl(0 + "");
        loadSoldItemtbl(0 + "");
        loadTopPurchase(0 + "");
    }//GEN-LAST:event_dayendBtnActionPerformed

    private void retItembtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_retItembtnMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_retItembtnMouseClicked

    private void retItembtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retItembtnActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null, "This functionality is Not Approved for use!");

       // returnItem ret = new returnItem();
        // ret.setVisible(true);

    }//GEN-LAST:event_retItembtnActionPerformed

    private void MaintasksMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaintasksMouseClicked
        // TODO add your handling code here:
        fill_Combo1();
        loadTable();
    }//GEN-LAST:event_MaintasksMouseClicked

    private void stocktblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stocktblMouseClicked
        // TODO add your handling code here:
        tableToFields1();
    }//GEN-LAST:event_stocktblMouseClicked

    private void stocktblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stocktblKeyReleased
        // TODO add your handling code here:
        tableToFields1();
    }//GEN-LAST:event_stocktblKeyReleased

    private void stockupdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockupdateBtnActionPerformed
        // TODO add your handling code here:
        stockupdate();
        loadTable();
        clearfields1();
    }//GEN-LAST:event_stockupdateBtnActionPerformed
    public void clearfields1() {
        itemQty.setText("");
        Item_name.setText("");
        item_code.setText("");
    }
    private void itmListPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_itmListPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        setLabel();
        if(itmList.getSelectedItem()!=null)
        show_image(itmList.getSelectedItem().toString());

    }//GEN-LAST:event_itmListPopupMenuWillBecomeInvisible
    private void show_image(String name) {

        String test, itemimg = null;

        try {
            rs = runS("select s.img from items as s where s.item_name= '" + name + "'");
            if (rs.next()) {
                itemimg = rs.getString("img");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        if (!itemimg.equals("") && !itemimg.equals("null")) {

            test = "src\\images\\" + itemimg;

            BufferedImage imgg = null;
            try {
                imgg = ImageIO.read(new File(test));
            } catch (IOException ex) {
                Logger.getLogger(Items.class.getName()).log(Level.SEVERE, null, ex);
            }
            Image image = imgg.getScaledInstance(imageLbl.getWidth(), imageLbl.getHeight(), Image.SCALE_DEFAULT);
            ImageIcon icon = new ImageIcon(image);
            imageLbl.setIcon(icon);
        }
    }
    private void removeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeBtnActionPerformed
        // TODO add your handling code here:
        int check = JOptionPane.showConfirmDialog(null, "Do you want to Delete ? ");
        if (check == 0) {
            int r = billTbl.getSelectedRow();
            String id = billTbl.getValueAt(r, 0).toString();
            String code = billTbl.getValueAt(r, 1).toString();
            String name = billTbl.getValueAt(r, 2).toString();
            //String price = billTbl.getValueAt(r, 3).toString();
            String qty = billTbl.getValueAt(r, 4).toString();
            String discount = billTbl.getValueAt(r, 5).toString();
            int total = Integer.parseInt(billTbl.getValueAt(r, 6).toString());
            try {
                if (runI("DELETE FROM copy_mapping WHERE sales_id='" + id + "' and item_name='" + name + "' and item_code= '" + code + "'"
                        + "and qty='" + qty + "' and discount = '" + discount + "' and total = '" + total + "'")) {
                    stockUpdate2(Integer.parseInt(qty), code, name);
                    set_totalAmmount();

                    JOptionPane.showMessageDialog(null, "Record removed !");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }

            loadTable1();
            clearfields();

        }
    }//GEN-LAST:event_removeBtnActionPerformed

    private void salesBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salesBtn1MouseClicked
        // TODO add your handling code here:
        topitemstbl.clearSelection();
    }//GEN-LAST:event_salesBtn1MouseClicked

    private void salesBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salesBtn1ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) topitemstbl.getModel();
        model.setRowCount(0);
        model = (DefaultTableModel) soldtbl.getModel();
        model.setRowCount(0);
        model = (DefaultTableModel) total_purchasetbl.getModel();
        model.setRowCount(0);
    }//GEN-LAST:event_salesBtn1ActionPerformed

    private void searchBillbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchBillbtnMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBillbtnMouseClicked
    private void show_date_time() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        dateLbl.setText(sdf.format(d));

        new Timer(0, new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Date d = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
                timeLbl.setText(sdf.format(d));
            }
        }).start();
    }
    private void searchBillbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBillbtnActionPerformed
        // TODO add your handling code here:
        Search_bill sb = new Search_bill();
        sb.setVisible(true);
    }//GEN-LAST:event_searchBillbtnActionPerformed

    private void addBtnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_addBtnKeyTyped
        // TODO add your handling code here:
        addBtn.doClick();
    }//GEN-LAST:event_addBtnKeyTyped

    private void itemtypeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtypeBtnActionPerformed
        // TODO add your handling code here:
        this.dispose();
        Supplier sb = new Supplier();
        sb.setVisible(true);
    }//GEN-LAST:event_itemtypeBtnActionPerformed

    private void itemQtyKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemQtyKeyTyped
        // TODO add your handling code here:
        checkInteger(itemQty, evt);
    }//GEN-LAST:event_itemQtyKeyTyped

    private void txt_qty_saleKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_qty_saleKeyTyped
        // TODO add your handling code here:
        checkInteger(txt_qty_sale, evt);
    }//GEN-LAST:event_txt_qty_saleKeyTyped

    private void txt_discountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_discountKeyTyped
        // TODO add your handling code here:
        checkInteger(txt_discount, evt);
    }//GEN-LAST:event_txt_discountKeyTyped

    private void itmListMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itmListMouseEntered
        // TODO add your handling code here:
       /* itmList.removeAllItems();

         try {

         rs = runS("SELECT item_name from items ");
         if(rs!=null){
         while (rs.next()) {
         itmList.addItem(rs.getString("item_name"));
         //  stockitemTxt.addItem(rs.getString("item_name"));
         }
         }
         } catch (Exception ex) {
         JOptionPane.showMessageDialog(null, ex);
         }*/
    }//GEN-LAST:event_itmListMouseEntered
    private void setEmptyTable() {
        DefaultTableModel model = (DefaultTableModel) this.billTbl.getModel();
        model.setRowCount(0);
    }
    private void removeBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeBtn1ActionPerformed
        // TODO add your handling code here:
        int check = JOptionPane.showConfirmDialog(null, "Do you want to Cancel ? ");
        if (check == 0) {
            if (runI("Delete from copy_mapping where sales_id='" + id + "'")) {
                JOptionPane.showMessageDialog(null, "Order Cancel Successfully");
                setEmptyTable();
            }
        }


    }//GEN-LAST:event_removeBtn1ActionPerformed
    public void checkInteger(JTextField txt, java.awt.event.KeyEvent evt) {
        String value = txt.getText();
        int l = value.length();
        if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' || evt.getKeyChar() == evt.VK_BACK_SPACE || evt.getKeyChar() == evt.VK_ENTER) {
            txt.setEditable(true);
        } else {
            txt.setEditable(false);
            JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
        }
    }

    private void set_totalAmmount() {
        try {
            String q = "select sum(total-discount) as total from copy_mapping where sales_id='" + id + "'";
            rs = runS(q);
            if (rs.next()) {
                totalTxt.setText(rs.getString("total"));
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    private void tableToFields1() {

        int r = stocktbl.getSelectedRow();
        // String itemid = stocktbl.getValueAt(r, 0).toString();
        String itemname = stocktbl.getValueAt(r, 2).toString();
        // if(!stocktbl.getValueAt(r, 2).toString().equals(null))
        String itemqty = stocktbl.getValueAt(r, 4).toString();
        String itemcode = stocktbl.getValueAt(r, 1).toString();

        item_code.setText(itemcode);
        Item_name.setText(itemname);
        itemQty.setText(itemqty);
    }

    private void stockupdate() {

        if (Integer.parseInt(itemQty.getText()) > 0) {
            int r = stocktbl.getSelectedRow();
            String id = stocktbl.getValueAt(r, 0).toString();
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            //  int qty1 = Integer.parseInt(Item_name.getText());
            int qty1 = Integer.parseInt(itemQty.getText());

            if (runI("UPDATE stocks SET qty=qty+'" + qty1 + "',total_qty=total_qty+'" + qty1 + "',last_update='" + timestamp + "' WHERE stock_id ='" + id + "'")) {
                JOptionPane.showMessageDialog(null, "Stock Updated !");

            }
        } else {
            JOptionPane.showMessageDialog(null, "Negative values are not allowed!");
        }
    }

    private void stockUpdate1(int qty, String code, String name) {
        if (qty > 0) {
            runI("UPDATE stocks SET qty=qty-'" + qty + "' WHERE item_code ='" + code + "' and "
                    + "stock_id = (select item_id from items where item_name = '" + name + "' and code= '" + code + "')");
        } else {
            JOptionPane.showMessageDialog(null, "Negative values are not allowed!");
        }

    }

    private void stockUpdate2(int qty, String code, String name) {
        runI("UPDATE stocks SET qty=qty+'" + qty + "' WHERE item_code ='" + code + "' and "
                + "stock_id = (select item_id from items where item_name = '" + name + "' and code= '" + code + "')");
    }

    private void loadTable() {

        rs = runS("SELECT s.stock_id as ID, s.item_code as code,i.item_name as name,i.supplier,s.qty,s.total_qty as Purchase_qty,s.last_update, s.state FROM stocks as s inner JOIN items as i on s.stock_id= i.item_id");
        stocktbl.setModel(DbUtils.resultSetToTableModel(rs));

    }

    private void loadSoldItemtbl(String days) {
        rs = runS("SELECT i.code, s.item_name as name,sum(s.qty) AS `Sold_qty`,sum(s.qty*i.purchase) as Purchase,sum(total) as Sold_price, (sum(total)-sum(s.qty*i.purchase)) as profit FROM sales_item_mapping as s inner join items as i on s.item_name = i.item_name where date_sold>= DATE(NOW()) + INTERVAL -'" + days + "' DAY GROUP BY s.item_name");
        soldtbl.setModel(DbUtils.resultSetToTableModel(rs));
    }

    private void loadTopPurchase(String days) {
        rs = runS("SELECT i.code, i.item_name as name ,s.total_qty AS `Purchase_Qty`, i.price*s.total_qty as Purchase_total FROM stocks as s INNER join items as i on i.item_id=s.stock_id where s.last_update>= DATE(NOW()) + INTERVAL -'" + days + "' DAY GROUP BY item_name");
        total_purchasetbl.setModel(DbUtils.resultSetToTableModel(rs));

    }

    private void loadTopitemstbl(String days) {
        rs = runS("SELECT item_code as code,item_name as name,\n"
                + "             sum(`qty`) AS `Top_sold`\n"
                + "    FROM     sales_item_mapping\n"
                + "      where date_sold>= DATE(NOW()) + INTERVAL -'" + days + "' DAY \n"
                + "   GROUP BY item_name\n"
                + "   ORDER BY Top_sold DESC\n"
                + " \n"
                + "    LIMIT    5;");
        topitemstbl.setModel(DbUtils.resultSetToTableModel(rs));

    }

    private void loadTopitemstblAll() {
        rs = runS("SELECT       `item_name`,\n"
                + "             sum(`qty`) AS `Top_sold`\n"
                + "    FROM     sales_item_mapping\n"
                + "   GROUP BY item_name\n"
                + "   ORDER BY `Top_sold` DESC\n"
                + " \n"
                + "    LIMIT    5");
        topitemstbl.setModel(DbUtils.resultSetToTableModel(rs));
    }

    /*private void setLogo(String user) {
     ImageIcon icon = new ImageIcon("images\\" + user + ".png");
     Image image = icon.getImage().getScaledInstance(logolbl.getWidth(), logolbl.getHeight(), Image.SCALE_SMOOTH);
     logolbl.setIcon(icon);
     }
     */
    private void loadTable1() {

        rs = runS("SELECT sales_id as Order_ID, item_code as code,item_name as name, `price`, `qty`, `discount`, `total`,date_sold FROM `copy_mapping` WHERE sales_id='" + id + "'");
        billTbl.setModel(DbUtils.resultSetToTableModel(rs));

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Mainframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CompanyDetails;
    private javax.swing.JPanel Datetime;
    private javax.swing.JTextField Item_name;
    private javax.swing.JPanel Mainpanel;
    private javax.swing.JTabbedPane Maintasks;
    private javax.swing.JPanel MidPanel;
    private javax.swing.JLabel RavenSoftDesigns;
    private javax.swing.JPanel Reportpanel;
    private javax.swing.JPanel Shoppanel;
    private javax.swing.JPanel Stockpanel;
    private javax.swing.JPanel SystemOption;
    private javax.swing.JPanel Topanel;
    private javax.swing.JPanel Utilitypanel;
    private javax.swing.JButton addBtn;
    private javax.swing.JButton backupdbBtn;
    private javax.swing.JTable billTbl;
    private javax.swing.JPanel billpanel;
    private javax.swing.JScrollPane billtblpanel;
    private javax.swing.JPanel bottom;
    private javax.swing.JButton calculatorBtn;
    private javax.swing.JPanel cashpanel;
    private javax.swing.JLabel closeBtn;
    private javax.swing.JLabel dateLbl;
    private javax.swing.JButton dayendBtn;
    private javax.swing.JLabel discountLbl;
    private javax.swing.JLabel imageLbl;
    private javax.swing.JPanel input;
    private javax.swing.JPanel inputpanel;
    private javax.swing.JButton itemBtn;
    private javax.swing.JTextField itemQty;
    private javax.swing.JTextField item_code;
    private javax.swing.JPanel itemdetailspanel;
    private javax.swing.JButton itemtypeBtn;
    private javax.swing.JLabel itmLbl;
    private javax.swing.JComboBox<String> itmList;
    private javax.swing.JLabel itmpriceLbl;
    private javax.swing.JLabel itmpriceTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel logolbl;
    private javax.swing.JLabel minimizeBtn;
    private javax.swing.JButton monthendBtn;
    private java.awt.Label paidLbl;
    private java.awt.TextField paidTxt;
    private java.awt.Button payBtn;
    private javax.swing.JLabel qtyLbl;
    private javax.swing.JLabel qtyLbl1;
    private javax.swing.JLabel qtystockLbl;
    private javax.swing.JLabel qtystockTxt;
    private javax.swing.JButton removeBtn;
    private javax.swing.JButton removeBtn1;
    private javax.swing.JPanel reportsubpanel;
    private javax.swing.JLabel reporttitleLbl;
    private javax.swing.JButton retItembtn;
    private java.awt.Label returnLbl;
    private java.awt.Label returnTxt;
    private javax.swing.JButton salesBtn;
    private javax.swing.JButton salesBtn1;
    private javax.swing.JLabel salesreportLbl;
    private javax.swing.JButton searchBillbtn;
    private javax.swing.JPanel shopmainpanel;
    private javax.swing.JTable soldtbl;
    private javax.swing.JPanel stockinputpanel;
    private javax.swing.JLabel stockitemLbl;
    private javax.swing.JPanel stockmainpanel;
    private javax.swing.JLabel stockqtyLbl;
    private javax.swing.JPanel stocksubmainpanel;
    private javax.swing.JTable stocktbl;
    private javax.swing.JLabel stocktitleLbl;
    private javax.swing.JButton stockupdateBtn;
    private javax.swing.JButton stockupdateBtn1;
    private javax.swing.JLabel stockweightLbl;
    private javax.swing.JScrollPane tblscrolpanel;
    private javax.swing.JLabel timeLbl;
    private javax.swing.JPanel topitem1;
    private javax.swing.JPanel topitem4;
    private javax.swing.JPanel topitem5;
    private javax.swing.JTable topitemstbl;
    private javax.swing.JLabel topsellingitemLbl;
    private javax.swing.JPanel topsellingpanel;
    private java.awt.Label totalLbl;
    private java.awt.Label totalTxt;
    private javax.swing.JTable total_purchasetbl;
    private javax.swing.JTextField txt_discount;
    private javax.swing.JTextField txt_itemcode;
    private javax.swing.JTextField txt_qty_sale;
    private javax.swing.JLabel updateitemlist;
    private javax.swing.JPanel utilitysubpanel;
    private javax.swing.JLabel utilitytitleLbl;
    private javax.swing.JButton weekendBtn;
    private javax.swing.JButton yearendBtn;
    // End of variables declaration//GEN-END:variables
}
