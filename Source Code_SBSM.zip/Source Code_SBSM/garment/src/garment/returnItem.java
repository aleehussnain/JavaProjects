
package garment;

import connection.DbConnection;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;


public class returnItem extends javax.swing.JFrame {

   
     Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    public returnItem() {
        initComponents();
        this.setLocationRelativeTo(null);
         con = DbConnection.getConnection();
         fill_combo();
         try {
            setIconImage(ImageIO.read(new File("gem_shop_icon.png")));
        } catch (IOException ex) {
            Logger.getLogger(Mainframe.class.getName()).log(Level.SEVERE, null, ex);
        }setTitle("AMANAT GARMENTS");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnpanel = new javax.swing.JPanel();
        iteminputpanel = new javax.swing.JPanel();
        searchLbl1 = new javax.swing.JLabel();
        searchLbl3 = new javax.swing.JLabel();
        retqtytxt = new javax.swing.JTextField();
        retnametxt = new javax.swing.JComboBox();
        clearBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        leftpanel1 = new javax.swing.JPanel();
        mainLbl = new javax.swing.JLabel();
        closeBtn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 153, 153));
        setUndecorated(true);

        btnpanel.setBackground(new java.awt.Color(204, 204, 255));
        btnpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 10));

        iteminputpanel.setBackground(new java.awt.Color(204, 204, 255));
        iteminputpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 0));

        searchLbl1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl1.setText("Name");

        searchLbl3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl3.setText("Qty");

        retqtytxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                retqtytxtKeyTyped(evt);
            }
        });

        clearBtn.setBackground(new java.awt.Color(255, 255, 153));
        clearBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        clearBtn.setText("Clear");
        clearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(204, 204, 255));
        updateBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        updateBtn.setText("Return");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout iteminputpanelLayout = new javax.swing.GroupLayout(iteminputpanel);
        iteminputpanel.setLayout(iteminputpanelLayout);
        iteminputpanelLayout.setHorizontalGroup(
            iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iteminputpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchLbl3, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(retnametxt, 0, 289, Short.MAX_VALUE)
                    .addComponent(retqtytxt))
                .addContainerGap(77, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, iteminputpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(93, 93, 93))
        );
        iteminputpanelLayout.setVerticalGroup(
            iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iteminputpanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(retnametxt, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchLbl3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(retqtytxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44))
        );

        leftpanel1.setBackground(new java.awt.Color(0, 153, 153));
        leftpanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        mainLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        mainLbl.setForeground(new java.awt.Color(255, 255, 255));
        mainLbl.setText("Return Item");

        closeBtn.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 255, 255));
        closeBtn.setText("X");
        closeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout leftpanel1Layout = new javax.swing.GroupLayout(leftpanel1);
        leftpanel1.setLayout(leftpanel1Layout);
        leftpanel1Layout.setHorizontalGroup(
            leftpanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(leftpanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanel1Layout.createSequentialGroup()
                        .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(163, 163, 163))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanel1Layout.createSequentialGroup()
                        .addComponent(closeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        leftpanel1Layout.setVerticalGroup(
            leftpanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(closeBtn)
                .addGap(5, 5, 5)
                .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout btnpanelLayout = new javax.swing.GroupLayout(btnpanel);
        btnpanel.setLayout(btnpanelLayout);
        btnpanelLayout.setHorizontalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addComponent(iteminputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 15, Short.MAX_VALUE))
            .addComponent(leftpanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        btnpanelLayout.setVerticalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addComponent(leftpanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(iteminputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void clearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnActionPerformed
        // TODO add your handling code here:
        clearfields();
    }//GEN-LAST:event_clearBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        // TODO add your handling code here:
        updatereturn();
        //loadItemToTable();
        clearfields();
    }//GEN-LAST:event_updateBtnActionPerformed

    private void closeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeBtnMouseClicked
        // close btn:
        this.dispose();
    }//GEN-LAST:event_closeBtnMouseClicked

    private void retqtytxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_retqtytxtKeyTyped
        // TODO add your handling code here:
        new Items().checkInteger(retqtytxt, evt);
    }//GEN-LAST:event_retqtytxtKeyTyped
 public void clearfields() {
        retnametxt.removeAllItems();
        retqtytxt.setText("");
        fill_combo();
       
    }
     public void updatereturn(){
         if(!retqtytxt.getText().equals("") && retnametxt.getSelectedIndex()!=-1){
             if(Integer.parseInt(retqtytxt.getText())>0){
         
         try {
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    int qty1 = Integer.parseInt(retqtytxt.getText());
    String name = retnametxt.getSelectedItem().toString();
    
    
            String updatequery ="UPDATE stocks SET qty=qty+"+qty1+",last_update='"+timestamp+"' WHERE item_code ="
                    + "(select code from items where item_name='"+name+"')";
            //updatequery = "UPDATE stocks SET item_name='"+itemname+"' WHERE stock_id='"+itemid+"'";
            pst = con.prepareStatement(updatequery);
            pst.execute();
                 JOptionPane.showMessageDialog(null, "Item Returned Successfully !");

     }catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e);
        }
        }else
                         JOptionPane.showMessageDialog(rootPane, "Negative are not allowed !");

        }else
         JOptionPane.showMessageDialog(rootPane, "Fields can not be empty !");      

        
    }
     private void fill_combo(){
         retnametxt.removeAllItems();
           try{
         String loaddata ="SELECT item_name from items ";
            pst = con.prepareStatement(loaddata);
            rs = pst.executeQuery(); 
            
            while(rs.next()){
                retnametxt.addItem(rs.getString("item_name"));
            }
        }
        catch(Exception ex){
                        JOptionPane.showMessageDialog(null, ex);}
     }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(returnItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(returnItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(returnItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(returnItem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new returnItem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel btnpanel;
    private javax.swing.JButton clearBtn;
    private javax.swing.JLabel closeBtn;
    private javax.swing.JPanel iteminputpanel;
    private javax.swing.JPanel leftpanel1;
    private javax.swing.JLabel mainLbl;
    private javax.swing.JComboBox retnametxt;
    private javax.swing.JTextField retqtytxt;
    private javax.swing.JLabel searchLbl1;
    private javax.swing.JLabel searchLbl3;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
