package garment;

import connection.DbConnection;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;



public class Backups extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    String path = null;
    Process pr = null;

    public Backups() {
        initComponents();
        try {
            setIconImage(ImageIO.read(new File("gem_shop_icon.png")));
        } catch (IOException ex) {
            Logger.getLogger(Mainframe.class.getName()).log(Level.SEVERE, null, ex);
        }
        setTitle("AMANAT GARMENTS");
        this.setLocationRelativeTo(null);
        con = DbConnection.getConnection();
        loadItemToTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainpanel = new javax.swing.JPanel();
        leftpanel = new javax.swing.JPanel();
        serchpanel = new javax.swing.JPanel();
        searchLbl = new javax.swing.JLabel();
        searchTxt = new javax.swing.JTextField();
        btnpanel = new javax.swing.JPanel();
        createBtn = new javax.swing.JButton();
        iteminputpanel = new javax.swing.JPanel();
        searchLbl1 = new javax.swing.JLabel();
        backuplocationBtn = new javax.swing.JButton();
        backupdatetxt = new javax.swing.JLabel();
        backuplocationTxt = new javax.swing.JLabel();
        rightpanel = new javax.swing.JPanel();
        itmsLbl = new javax.swing.JLabel();
        backupTbl = new javax.swing.JScrollPane();
        itemsTbl = new javax.swing.JTable();
        mainLbl = new javax.swing.JLabel();
        closeBtn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        mainpanel.setBackground(new java.awt.Color(0, 153, 153));
        mainpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 10));

        leftpanel.setBackground(new java.awt.Color(204, 204, 255));
        leftpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        serchpanel.setBackground(new java.awt.Color(204, 204, 255));
        serchpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl.setText("Search");

        searchTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        searchTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchTxtActionPerformed(evt);
            }
        });
        searchTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchTxtKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout serchpanelLayout = new javax.swing.GroupLayout(serchpanel);
        serchpanel.setLayout(serchpanelLayout);
        serchpanelLayout.setHorizontalGroup(
            serchpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(serchpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(92, Short.MAX_VALUE))
        );
        serchpanelLayout.setVerticalGroup(
            serchpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(serchpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(serchpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnpanel.setBackground(new java.awt.Color(204, 204, 255));
        btnpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        createBtn.setBackground(new java.awt.Color(153, 255, 153));
        createBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn.setText("Create");
        createBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout btnpanelLayout = new javax.swing.GroupLayout(btnpanel);
        btnpanel.setLayout(btnpanelLayout);
        btnpanelLayout.setHorizontalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btnpanelLayout.setVerticalGroup(
            btnpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btnpanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        iteminputpanel.setBackground(new java.awt.Color(204, 204, 255));
        iteminputpanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl1.setText("Backup Date");

        backuplocationBtn.setText("Browse");
        backuplocationBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backuplocationBtnActionPerformed(evt);
            }
        });

        backupdatetxt.setBackground(new java.awt.Color(0, 0, 0));
        backupdatetxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        backupdatetxt.setText("20/03/2020");

        backuplocationTxt.setBackground(new java.awt.Color(0, 0, 0));
        backuplocationTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        backuplocationTxt.setText("C:\\garments");

        javax.swing.GroupLayout iteminputpanelLayout = new javax.swing.GroupLayout(iteminputpanel);
        iteminputpanel.setLayout(iteminputpanelLayout);
        iteminputpanelLayout.setHorizontalGroup(
            iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iteminputpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backuplocationBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(backupdatetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backuplocationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        iteminputpanelLayout.setVerticalGroup(
            iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iteminputpanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backupdatetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(iteminputpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backuplocationBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backuplocationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(79, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout leftpanelLayout = new javax.swing.GroupLayout(leftpanel);
        leftpanel.setLayout(leftpanelLayout);
        leftpanelLayout.setHorizontalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(serchpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(iteminputpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        leftpanelLayout.setVerticalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(serchpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(iteminputpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        rightpanel.setBackground(new java.awt.Color(204, 204, 255));
        rightpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        itmsLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        itmsLbl.setText("Backups");

        backupTbl.setBackground(new java.awt.Color(153, 153, 255));

        itemsTbl.setBackground(new java.awt.Color(204, 204, 204));
        itemsTbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        itemsTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "backup id", "bachup date"
            }
        ));
        itemsTbl.setGridColor(new java.awt.Color(204, 204, 204));
        itemsTbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        itemsTbl.setSelectionForeground(new java.awt.Color(0, 0, 0));
        itemsTbl.setShowHorizontalLines(false);
        backupTbl.setViewportView(itemsTbl);

        javax.swing.GroupLayout rightpanelLayout = new javax.swing.GroupLayout(rightpanel);
        rightpanel.setLayout(rightpanelLayout);
        rightpanelLayout.setHorizontalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(207, 207, 207)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(179, Short.MAX_VALUE))
            .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(rightpanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(backupTbl, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        rightpanelLayout.setVerticalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(rightpanelLayout.createSequentialGroup()
                    .addGap(49, 49, 49)
                    .addComponent(backupTbl, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(50, Short.MAX_VALUE)))
        );

        mainLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        mainLbl.setForeground(new java.awt.Color(255, 255, 255));
        mainLbl.setText("Backups Management");

        closeBtn.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        closeBtn.setForeground(new java.awt.Color(255, 255, 255));
        closeBtn.setText("X");
        closeBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout mainpanelLayout = new javax.swing.GroupLayout(mainpanel);
        mainpanel.setLayout(mainpanelLayout);
        mainpanelLayout.setHorizontalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(leftpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rightpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(294, 294, 294)
                .addComponent(closeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        mainpanelLayout.setVerticalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainpanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(mainLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(closeBtn))
                .addGap(18, 18, 18)
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(leftpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rightpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeBtnMouseClicked
        // close btn:
        this.dispose();
    }//GEN-LAST:event_closeBtnMouseClicked

    private void searchTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchTxtActionPerformed

    private void createBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtnActionPerformed
        // TODO add your handling code here:
        //Timestamp 1
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        int x = backuplocationTxt.getText().length();

        if (x > 0) {

            try {
                Runtime run = Runtime.getRuntime();                  //db -u username and -p pass and -B databaseName
                pr = run.exec("C:/xampp/mysql/bin/mysqldump.exe -uroot -proot --add-drop-database -B garments -r" + path);

                int processCompelete = pr.waitFor();
                if (processCompelete == 0) {

                    String insertQuery = "INSERT INTO backup (back_Up) VALUES ('" + timestamp + "')";
                    pst = con.prepareStatement(insertQuery);
                    pst.execute();

                    JOptionPane.showMessageDialog(rootPane, "Backup creted Succesfully !");

                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
            loadItemToTable();
        }
    }//GEN-LAST:event_createBtnActionPerformed

    private void searchTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchTxtKeyReleased
        // TODO add your handling code here:
        search();

    }//GEN-LAST:event_searchTxtKeyReleased

    private void backuplocationBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backuplocationBtnActionPerformed
        // TODO add your handling code here:
        //Timestamp timestamp = new Timestamp(System.currentTimeMillis());

        JFileChooser jf = new JFileChooser();
        jf.showOpenDialog(this);
        String date;
        date = new SimpleDateFormat("YYYY-MM-DD").format(new Date());

        try {
            File f = jf.getSelectedFile();
            path = f.getAbsolutePath();
            path = path.replace('\\', '/');
            path = path + "_" + date + ".sql";
            backuplocationTxt.setText(path);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);

        }
    }//GEN-LAST:event_backuplocationBtnActionPerformed
    public void search() {
        String srch = searchTxt.getText();

        rs = runS("SELECT * FROM backup WHERE ID LIKE '%" + srch + "%'");
        itemsTbl.setModel(DbUtils.resultSetToTableModel(rs));

    }

    public void loadItemToTable() {

        rs = runS("SELECT ID as ID, back_Up as backup_Date FROM backup");
        itemsTbl.setModel(DbUtils.resultSetToTableModel(rs));

    }

    private ResultSet runS(String q) {
        try {
            pst = con.prepareStatement(q);
            rs = pst.executeQuery();
            if (!rs.equals(null)) {
                return rs;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Backups().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane backupTbl;
    private javax.swing.JLabel backupdatetxt;
    private javax.swing.JButton backuplocationBtn;
    private javax.swing.JLabel backuplocationTxt;
    private javax.swing.JPanel btnpanel;
    private javax.swing.JLabel closeBtn;
    private javax.swing.JButton createBtn;
    private javax.swing.JPanel iteminputpanel;
    private javax.swing.JTable itemsTbl;
    private javax.swing.JLabel itmsLbl;
    private javax.swing.JPanel leftpanel;
    private javax.swing.JLabel mainLbl;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JPanel rightpanel;
    private javax.swing.JLabel searchLbl;
    private javax.swing.JLabel searchLbl1;
    private javax.swing.JTextField searchTxt;
    private javax.swing.JPanel serchpanel;
    // End of variables declaration//GEN-END:variables
}
