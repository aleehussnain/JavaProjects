package garment;

import connection.SqlConnection;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;



public class JohnBackup extends javax.swing.JFrame {

    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    String filePaht = null;
    Process process = null;

    public JohnBackup() {
        initComponents();
        try {
            setIconImage(ImageIO.read(new File("gem_shop_icon.png")));
        } catch (IOException ex) {
            Logger.getLogger(JohnGarments.class.getName()).log(Level.SEVERE, null, ex);
        }
        setTitle("AMANAT GARMENTS");
        this.setLocationRelativeTo(null);
        connection = SqlConnection.getConnection();
        loadItemToTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainpanel = new javax.swing.JPanel();
        dataPanel = new javax.swing.JPanel();
        findPanel = new javax.swing.JPanel();
        searchLbl = new javax.swing.JLabel();
        searchTxt = new javax.swing.JTextField();
        createButtonPanel = new javax.swing.JPanel();
        createBtn = new javax.swing.JButton();
        itemInsertPanel = new javax.swing.JPanel();
        searchLbl1 = new javax.swing.JLabel();
        backuplocationBtn = new javax.swing.JButton();
        backupdatetxt = new javax.swing.JLabel();
        backuplocationTxt = new javax.swing.JLabel();
        viewPanel = new javax.swing.JPanel();
        itmsLbl = new javax.swing.JLabel();
        backupTbl = new javax.swing.JScrollPane();
        itemsTbl = new javax.swing.JTable();
        labelLogo = new javax.swing.JLabel();
        lablelClose = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        mainpanel.setBackground(new java.awt.Color(102, 102, 102));
        mainpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 255), 10));

        dataPanel.setBackground(new java.awt.Color(204, 204, 255));
        dataPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        findPanel.setBackground(new java.awt.Color(0, 204, 204));
        findPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl.setText("Search");

        searchTxt.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        searchTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchTxtActionPerformed(evt);
            }
        });
        searchTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchTxtKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout findPanelLayout = new javax.swing.GroupLayout(findPanel);
        findPanel.setLayout(findPanelLayout);
        findPanelLayout.setHorizontalGroup(
            findPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(findPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(92, Short.MAX_VALUE))
        );
        findPanelLayout.setVerticalGroup(
            findPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(findPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(findPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        createButtonPanel.setBackground(new java.awt.Color(0, 204, 204));
        createButtonPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        createBtn.setBackground(new java.awt.Color(153, 255, 153));
        createBtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        createBtn.setText("Create");
        createBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout createButtonPanelLayout = new javax.swing.GroupLayout(createButtonPanel);
        createButtonPanel.setLayout(createButtonPanelLayout);
        createButtonPanelLayout.setHorizontalGroup(
            createButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(createButtonPanelLayout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        createButtonPanelLayout.setVerticalGroup(
            createButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(createButtonPanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(createBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        itemInsertPanel.setBackground(new java.awt.Color(0, 102, 102));
        itemInsertPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        searchLbl1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        searchLbl1.setText("Backup Date");

        backuplocationBtn.setText("Browse");
        backuplocationBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backuplocationBtnActionPerformed(evt);
            }
        });

        backupdatetxt.setBackground(new java.awt.Color(0, 0, 0));
        backupdatetxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        backupdatetxt.setText("20/03/2020");

        backuplocationTxt.setBackground(new java.awt.Color(0, 0, 0));
        backuplocationTxt.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        backuplocationTxt.setText("C:\\garments");

        javax.swing.GroupLayout itemInsertPanelLayout = new javax.swing.GroupLayout(itemInsertPanel);
        itemInsertPanel.setLayout(itemInsertPanelLayout);
        itemInsertPanelLayout.setHorizontalGroup(
            itemInsertPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(itemInsertPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(itemInsertPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(backuplocationBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(itemInsertPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(backupdatetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backuplocationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(92, Short.MAX_VALUE))
        );
        itemInsertPanelLayout.setVerticalGroup(
            itemInsertPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(itemInsertPanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(itemInsertPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backupdatetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(itemInsertPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backuplocationBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backuplocationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(79, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout dataPanelLayout = new javax.swing.GroupLayout(dataPanel);
        dataPanel.setLayout(dataPanelLayout);
        dataPanelLayout.setHorizontalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(findPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(createButtonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(itemInsertPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        dataPanelLayout.setVerticalGroup(
            dataPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dataPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(findPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(itemInsertPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(createButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        viewPanel.setBackground(new java.awt.Color(102, 102, 102));
        viewPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        itmsLbl.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        itmsLbl.setText("Backups");

        backupTbl.setBackground(new java.awt.Color(153, 153, 255));

        itemsTbl.setBackground(new java.awt.Color(204, 204, 204));
        itemsTbl.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        itemsTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "backup id", "bachup date"
            }
        ));
        itemsTbl.setGridColor(new java.awt.Color(204, 204, 204));
        itemsTbl.setSelectionBackground(new java.awt.Color(153, 153, 255));
        backupTbl.setViewportView(itemsTbl);

        javax.swing.GroupLayout viewPanelLayout = new javax.swing.GroupLayout(viewPanel);
        viewPanel.setLayout(viewPanelLayout);
        viewPanelLayout.setHorizontalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewPanelLayout.createSequentialGroup()
                .addGap(207, 207, 207)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(179, Short.MAX_VALUE))
            .addGroup(viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(backupTbl, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        viewPanelLayout.setVerticalGroup(
            viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewPanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(itmsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(viewPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewPanelLayout.createSequentialGroup()
                    .addGap(49, 49, 49)
                    .addComponent(backupTbl, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(50, Short.MAX_VALUE)))
        );

        labelLogo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        labelLogo.setForeground(new java.awt.Color(255, 255, 255));
        labelLogo.setText("Backups Management");

        lablelClose.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        lablelClose.setForeground(new java.awt.Color(255, 255, 255));
        lablelClose.setText("X");
        lablelClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lablelCloseMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout mainpanelLayout = new javax.swing.GroupLayout(mainpanel);
        mainpanel.setLayout(mainpanelLayout);
        mainpanelLayout.setHorizontalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dataPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(viewPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(294, 294, 294)
                .addComponent(lablelClose, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        mainpanelLayout.setVerticalGroup(
            mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainpanelLayout.createSequentialGroup()
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainpanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(labelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lablelClose))
                .addGap(18, 18, 18)
                .addGroup(mainpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dataPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(viewPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lablelCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lablelCloseMouseClicked
        // close btn:
        this.dispose();
    }//GEN-LAST:event_lablelCloseMouseClicked

    private void searchTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchTxtActionPerformed

    private void createBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createBtnActionPerformed
        // TODO add your handling code here:
        //Timestamp 1
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        int x = backuplocationTxt.getText().length();

        if (x > 0) {

            try {
                Runtime run = Runtime.getRuntime();                  //db -u username and -p pass and -B databaseName
                process = run.exec("C:/xampp/mysql/bin/mysqldump.exe -uroot -proot --add-drop-database -B garments -r" + filePaht);

                int processCompelete = process.waitFor();
                if (processCompelete == 0) {

                    String insertQuery = "INSERT INTO backup (back_Up) VALUES ('" + timestamp + "')";
                    preparedStatement = connection.prepareStatement(insertQuery);
                    preparedStatement.execute();

                    JOptionPane.showMessageDialog(rootPane, "Backup creted Succesfully !");

                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
            loadItemToTable();
        }
    }//GEN-LAST:event_createBtnActionPerformed

    private void searchTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchTxtKeyReleased
        // TODO add your handling code here:
        search();

    }//GEN-LAST:event_searchTxtKeyReleased

    private void backuplocationBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backuplocationBtnActionPerformed
        // TODO add your handling code here:
        //Timestamp timestamp = new Timestamp(System.currentTimeMillis());

        JFileChooser jf = new JFileChooser();
        jf.showOpenDialog(this);
        String date;
        date = new SimpleDateFormat("YYYY-MM-DD").format(new Date());

        try {
            File f = jf.getSelectedFile();
            filePaht = f.getAbsolutePath();
            filePaht = filePaht.replace('\\', '/');
            filePaht = filePaht + "_" + date + ".sql";
            backuplocationTxt.setText(filePaht);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);

        }
    }//GEN-LAST:event_backuplocationBtnActionPerformed
    public void search() {
        String srch = searchTxt.getText();

        resultSet = runS("SELECT * FROM backup WHERE ID LIKE '%" + srch + "%'");
        itemsTbl.setModel(DbUtils.resultSetToTableModel(resultSet));

    }

    public void loadItemToTable() {

        resultSet = runS("SELECT ID as ID, back_Up as backup_Date FROM backup");
        itemsTbl.setModel(DbUtils.resultSetToTableModel(resultSet));

    }

    private ResultSet runS(String q) {
        try {
            preparedStatement = connection.prepareStatement(q);
            resultSet = preparedStatement.executeQuery();
            if (!resultSet.equals(null)) {
                return resultSet;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JohnBackup().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane backupTbl;
    private javax.swing.JLabel backupdatetxt;
    private javax.swing.JButton backuplocationBtn;
    private javax.swing.JLabel backuplocationTxt;
    private javax.swing.JButton createBtn;
    private javax.swing.JPanel createButtonPanel;
    private javax.swing.JPanel dataPanel;
    private javax.swing.JPanel findPanel;
    private javax.swing.JPanel itemInsertPanel;
    private javax.swing.JTable itemsTbl;
    private javax.swing.JLabel itmsLbl;
    private javax.swing.JLabel labelLogo;
    private javax.swing.JLabel lablelClose;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JLabel searchLbl;
    private javax.swing.JLabel searchLbl1;
    private javax.swing.JTextField searchTxt;
    private javax.swing.JPanel viewPanel;
    // End of variables declaration//GEN-END:variables
}
